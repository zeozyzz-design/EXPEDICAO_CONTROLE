"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { criarClienteNavegador } from "@/lib/supabase/client";
import type { Etapa, Evento, MetaSla, Ocorrencia, Perfil, Romaneio, TipoOcorrencia } from "@/lib/domain";

type Estado = {
  pronto: boolean;
  erro: string | null;
  eu: Perfil;
  etapas: Etapa[];
  romaneios: Romaneio[];
  eventos: Evento[];
  ocorrencias: Ocorrencia[];
  tipos: TipoOcorrencia[];
  metas: Record<number, number>;
  perfis: Perfil[];
  limparErro: () => void;
  recarregar: () => Promise<void>;
  lancarRomaneio: (v: { numero: string; transportadora: string; qtdNotas: number; arquivo: File | null }) => Promise<boolean>;
  registrarCheckpoint: (romaneioId: string, cp: number, nota?: string) => Promise<boolean>;
  estornar: (romaneioId: string, cp: number, justificativa: string) => Promise<boolean>;
  abrirOcorrencia: (v: {
    romaneioId: string;
    cp: number;
    tipo: string;
    responsavel: string;
    motivo?: string;
    descricao?: string;
    chamado?: string;
  }) => Promise<boolean>;
  fecharOcorrencia: (id: string) => Promise<boolean>;
  definirMeta: (cp: number, minutos: number) => Promise<boolean>;
  urlAnexo: (path: string) => Promise<string | null>;
  verificarIntegridade: () => Promise<Array<{ numero: string; cp: number; problema: string }> | null>;
};

const Ctx = createContext<Estado | null>(null);

export function useDados() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useDados fora do provedor");
  return ctx;
}

export function ProvedorDados({ children, perfilInicial }: { children: React.ReactNode; perfilInicial: Perfil }) {
  const supabase = useMemo(() => criarClienteNavegador(), []);
  const [pronto, setPronto] = useState(false);
  const [erro, setErro] = useState<string | null>(null);
  const [eu, setEu] = useState<Perfil>(perfilInicial);
  const [etapas, setEtapas] = useState<Etapa[]>([]);
  const [romaneios, setRomaneios] = useState<Romaneio[]>([]);
  const [eventos, setEventos] = useState<Evento[]>([]);
  const [ocorrencias, setOcorrencias] = useState<Ocorrencia[]>([]);
  const [tipos, setTipos] = useState<TipoOcorrencia[]>([]);
  const [metas, setMetas] = useState<Record<number, number>>({});
  const [perfis, setPerfis] = useState<Perfil[]>([]);

  const recarregar = useCallback(async () => {
    const [et, ro, ev, oc, ti, sl, pe] = await Promise.all([
      supabase.from("etapas").select("*").order("cp"),
      supabase.from("romaneios").select("*"),
      supabase.from("eventos").select("*"),
      supabase.from("ocorrencias").select("*"),
      supabase.from("tipos_ocorrencia").select("*").eq("ativo", true).order("id"),
      supabase.from("sla_metas").select("cp, minutos").is("vigente_ate", null).is("transportadora", null),
      supabase.from("perfis").select("*"),
    ]);

    if (et.data) setEtapas(et.data as Etapa[]);
    if (ro.data) setRomaneios(ro.data as Romaneio[]);
    if (ev.data) setEventos(ev.data as Evento[]);
    if (oc.data) setOcorrencias(oc.data as Ocorrencia[]);
    if (ti.data) setTipos(ti.data as TipoOcorrencia[]);
    if (pe.data) {
      setPerfis(pe.data as Perfil[]);
      const meu = (pe.data as Perfil[]).find((p) => p.id === perfilInicial.id);
      if (meu) setEu(meu);
    }
    if (sl.data) {
      const m: Record<number, number> = {};
      for (const linha of sl.data as MetaSla[]) m[linha.cp] = linha.minutos;
      setMetas(m);
    }
    setPronto(true);
  }, [supabase, perfilInicial.id]);

  useEffect(() => {
    recarregar();
  }, [recarregar]);

  // Tempo real: a fila aparece sozinha quando a CEVA envia um romaneio.
  useEffect(() => {
    const canal = supabase
      .channel("expedicao")
      .on("postgres_changes", { event: "*", schema: "public", table: "romaneios" }, (p) => {
        const novo = p.new as Romaneio;
        if (p.eventType === "INSERT") setRomaneios((xs) => (xs.some((r) => r.id === novo.id) ? xs : [...xs, novo]));
        if (p.eventType === "UPDATE") setRomaneios((xs) => xs.map((r) => (r.id === novo.id ? novo : r)));
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "eventos" }, (p) => {
        const novo = p.new as Evento;
        setEventos((xs) => (xs.some((e) => e.id === novo.id) ? xs : [...xs, novo]));
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "ocorrencias" }, (p) => {
        const novo = p.new as Ocorrencia;
        if (p.eventType === "INSERT") setOcorrencias((xs) => (xs.some((o) => o.id === novo.id) ? xs : [...xs, novo]));
        if (p.eventType === "UPDATE") setOcorrencias((xs) => xs.map((o) => (o.id === novo.id ? novo : o)));
      })
      .subscribe();

    return () => {
      supabase.removeChannel(canal);
    };
  }, [supabase]);

  const falha = (e: { message?: string } | null, padrao: string) => {
    setErro(e?.message?.replace(/^.*?:\s*/, "") || padrao);
    return false;
  };

  const lancarRomaneio: Estado["lancarRomaneio"] = async ({ numero, transportadora, qtdNotas, arquivo }) => {
    let path: string | null = null;
    if (arquivo) {
      const nome = `${Date.now()}-${arquivo.name.replace(/[^\w.\-]/g, "_")}`;
      const { error } = await supabase.storage.from("anexos").upload(nome, arquivo);
      if (error) return falha(error, "A planilha não pôde ser enviada.");
      path = nome;
    }
    const { error } = await supabase.rpc("lancar_romaneio", {
      p_numero: numero,
      p_transportadora: transportadora,
      p_qtd_notas: qtdNotas,
      p_anexo_path: path,
      p_anexo_nome: arquivo?.name ?? null,
    });
    if (error) return falha(error, "O romaneio não foi lançado.");
    await recarregar();
    return true;
  };

  const registrarCheckpoint: Estado["registrarCheckpoint"] = async (romaneioId, cp, nota) => {
    const { error } = await supabase.rpc("registrar_checkpoint", {
      p_romaneio: romaneioId,
      p_cp: cp,
      p_tipo: "checkpoint",
      p_nota: nota ?? null,
    });
    if (error) return falha(error, "O checkpoint não foi gravado.");
    await recarregar();
    return true;
  };

  const estornar: Estado["estornar"] = async (romaneioId, cp, justificativa) => {
    const { error } = await supabase.rpc("registrar_checkpoint", {
      p_romaneio: romaneioId,
      p_cp: cp,
      p_tipo: "estorno",
      p_nota: justificativa,
    });
    if (error) return falha(error, "O estorno não foi gravado.");
    await recarregar();
    return true;
  };

  const abrirOcorrencia: Estado["abrirOcorrencia"] = async (v) => {
    const { error } = await supabase.rpc("abrir_ocorrencia", {
      p_romaneio: v.romaneioId,
      p_cp: v.cp,
      p_tipo: v.tipo,
      p_responsavel: v.responsavel,
      p_motivo: v.motivo ?? null,
      p_descricao: v.descricao ?? null,
      p_chamado: v.chamado ?? null,
    });
    if (error) return falha(error, "A ocorrência não foi registrada.");
    await recarregar();
    return true;
  };

  const fecharOcorrencia: Estado["fecharOcorrencia"] = async (id) => {
    const { error } = await supabase.rpc("fechar_ocorrencia", { p_ocorrencia: id });
    if (error) return falha(error, "Não foi possível fechar a ocorrência.");
    await recarregar();
    return true;
  };

  const definirMeta: Estado["definirMeta"] = async (cp, minutos) => {
    const { error } = await supabase.rpc("definir_meta_sla", { p_cp: cp, p_minutos: minutos });
    if (error) return falha(error, "A meta não foi salva.");
    await recarregar();
    return true;
  };

  const urlAnexo: Estado["urlAnexo"] = async (path) => {
    const { data } = await supabase.storage.from("anexos").createSignedUrl(path, 300);
    return data?.signedUrl ?? null;
  };

  const verificarIntegridade: Estado["verificarIntegridade"] = async () => {
    const { data, error } = await supabase.rpc("verificar_integridade");
    if (error) {
      falha(error, "A verificação não pôde ser executada.");
      return null;
    }
    return (data ?? []) as Array<{ numero: string; cp: number; problema: string }>;
  };

  return (
    <Ctx.Provider
      value={{
        pronto,
        erro,
        eu,
        etapas,
        romaneios,
        eventos,
        ocorrencias,
        tipos,
        metas,
        perfis,
        limparErro: () => setErro(null),
        recarregar,
        lancarRomaneio,
        registrarCheckpoint,
        estornar,
        abrirOcorrencia,
        fecharOcorrencia,
        definirMeta,
        urlAnexo,
        verificarIntegridade,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}
