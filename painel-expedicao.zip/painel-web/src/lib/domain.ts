export type PerfilTipo = "celere" | "ceva" | "transportadora" | "gerencia";
export type EmpresaResp = "CEVA" | "Celere" | "Transportadora" | "Inovatech";

export type Perfil = {
  id: string;
  nome: string;
  tipo: PerfilTipo;
  transportadora: string | null;
  ativo: boolean;
  criado_em: string;
};

export type Etapa = { cp: number; nome: string; curto: string; setor: "CEVA" | "Celere" | "Transportadora" };

export type Romaneio = {
  id: string;
  numero: string;
  transportadora: string;
  qtd_notas: number;
  anexo_path: string | null;
  anexo_nome: string | null;
  etapa_atual: number;
  criado_em: string;
  criado_por: string;
};

export type Evento = {
  id: string;
  romaneio_id: string;
  cp: number;
  tipo: "checkpoint" | "estorno";
  ocorrido_em: string;
  autor_id: string;
  autor_nome: string;
  por_master: boolean;
  nota: string | null;
  hash_prev: string;
  hash: string;
};

export type Ocorrencia = {
  id: string;
  romaneio_id: string;
  cp: number;
  tipo: string;
  motivo: string | null;
  descricao: string | null;
  responsavel: EmpresaResp;
  chamado: string | null;
  aberta_em: string;
  fechada_em: string | null;
  aberta_por: string;
  fechada_por: string | null;
};

export type TipoOcorrencia = {
  id: number;
  nome: string;
  onde: string;
  responsavel: EmpresaResp;
  exige_chamado: boolean;
  ativo: boolean;
};

export type MetaSla = { cp: number; minutos: number };

export const ETAPA_FINAL = 6;

export const TRANSPORTADORAS = ["JAT", "DHL", "CARVALIMA"] as const;
export const RESPONSAVEIS: EmpresaResp[] = ["CEVA", "Celere", "Transportadora", "Inovatech"];

export const MOTIVOS_EMISSAO = [
  "Nota não migrou do ERP",
  "NOTFIS não foi gerado",
  "NOTFIS gerado incompleto",
  "Romaneio divergente do enviado pela CEVA",
  "Sistema de emissão indisponível",
  "Outro motivo",
];

export const TIPO_EMISSAO_PARADA = "Emissão parada";

export const ROTULO_PERFIL: Record<PerfilTipo, string> = {
  celere: "Celere · acesso master",
  ceva: "CEVA · lança e acompanha",
  transportadora: "Transportadora · cargas próprias",
  gerencia: "Gerência Iveco · somente leitura",
};

export type Aba = "fila" | "histórico" | "indicadores" | "auditoria" | "usuarios";

export function abasDe(tipo: PerfilTipo): Aba[] {
  if (tipo === "celere") return ["fila", "histórico", "indicadores", "auditoria", "usuarios"];
  if (tipo === "gerencia") return ["fila", "histórico", "indicadores"];
  return ["fila", "histórico"];
}

export type Periodo = 7 | 30 | 90 | 0;

export const PERIODOS: Array<{ dias: Periodo; rotulo: string }> = [
  { dias: 7, rotulo: "7 dias" },
  { dias: 30, rotulo: "30 dias" },
  { dias: 90, rotulo: "90 dias" },
  { dias: 0, rotulo: "Tudo" },
];

export function dentroDoPeriodo(iso: string, dias: Periodo, agora: number) {
  if (!dias) return true;
  return new Date(iso).getTime() >= agora - dias * 86400000;
}

export function minutosEntre(a: string, b: string) {
  return (new Date(b).getTime() - new Date(a).getTime()) / 60000;
}

export function duracao(min: number) {
  if (!isFinite(min) || min < 0) return "—";
  const m = Math.floor(min);
  if (m < 60) return `${m}min`;
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (h < 24) return r ? `${h}h${String(r).padStart(2, "0")}` : `${h}h`;
  const d = Math.floor(h / 24);
  return `${d}d${h % 24}h`;
}

export function hora(iso: string) {
  return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
}

export function mediana(vals: number[]) {
  if (!vals.length) return NaN;
  const s = [...vals].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

export function percentil(vals: number[], p: number) {
  if (!vals.length) return NaN;
  const s = [...vals].sort((a, b) => a - b);
  const i = Math.min(s.length - 1, Math.max(0, Math.ceil((p / 100) * s.length) - 1));
  return s[i];
}

export function faixaSla(min: number, meta?: number): "ok" | "warn" | "crit" {
  if (!meta || !isFinite(min)) return "ok";
  if (min <= meta) return "ok";
  if (min <= meta * 2) return "warn";
  return "crit";
}

export function carimbos(eventos: Evento[]) {
  const m = new Map<number, string>();
  for (const e of eventos) {
    if (e.tipo !== "checkpoint") continue;
    const a = m.get(e.cp);
    if (!a || e.ocorrido_em > a) m.set(e.cp, e.ocorrido_em);
  }
  return m;
}

export function setorAtual(r: Romaneio, etapas: Etapa[]) {
  if (r.etapa_atual >= ETAPA_FINAL) return "Finalizado";
  return etapas.find((e) => e.cp === r.etapa_atual + 1)?.setor ?? "—";
}

export function podeRegistrar(p: Perfil, etapa: Etapa | undefined, r: Romaneio) {
  if (!etapa || p.tipo === "gerencia") return false;
  if (p.tipo === "celere") return true;
  if (etapa.setor === "CEVA") return p.tipo === "ceva";
  if (etapa.setor === "Celere") return false;
  return p.tipo === "transportadora" && p.transportadora === r.transportadora;
}

export function semanaDe(iso: string) {
  const d = new Date(iso);
  const dia = (d.getDay() + 6) % 7;
  const seg = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dia);
  return `${seg.getFullYear()}-${String(seg.getMonth() + 1).padStart(2, "0")}-${String(seg.getDate()).padStart(2, "0")}`;
}

export function diaCurto(chave: string) {
  const [, m, d] = chave.split("-");
  return `${d}/${m}`;
}

export function csv(linhas: Array<Array<string | number>>) {
  return linhas.map((l) => l.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
}

export function baixarCsv(nome: string, conteudo: string) {
  const blob = new Blob(["﻿" + conteudo], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nome;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
