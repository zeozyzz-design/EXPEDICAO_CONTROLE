"use client";

import { useEffect } from "react";

export function Modal({ titulo, children, onFechar }: { titulo: string; children: React.ReactNode; onFechar: () => void }) {
  useEffect(() => {
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onFechar();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [onFechar]);

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/55 sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label={titulo}>
      <div className="cartao max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t sm:rounded">
        <div className="flex items-center justify-between gap-4 border-b px-4 py-3">
          <h2 className="display text-base font-semibold">{titulo}</h2>
          <button className="btn btn-sec" onClick={onFechar}>
            Fechar
          </button>
        </div>
        <div className="grid gap-3 p-4">{children}</div>
      </div>
    </div>
  );
}

export function Chip({ tom, children }: { tom: "ok" | "warn" | "crit" | "neutro" | "marca"; children: React.ReactNode }) {
  const estilo =
    tom === "neutro"
      ? { background: "hsl(var(--muted))", color: "hsl(var(--muted-fg))" }
      : tom === "marca"
        ? { background: "hsl(var(--brand) / 0.12)", color: "hsl(var(--brand))" }
        : { background: `hsl(var(--${tom}-bg))`, color: `hsl(var(--${tom}))` };
  return (
    <span className="inline-flex items-center rounded-sm px-1.5 py-0.5 text-[11px] font-semibold" style={estilo}>
      {children}
    </span>
  );
}

export function Aviso({ texto, onFechar }: { texto: string; onFechar: () => void }) {
  return (
    <p
      className="mb-4 flex items-center gap-3 rounded border p-3 text-sm"
      style={{ background: "hsl(var(--crit-bg))", color: "hsl(var(--crit))", borderColor: "hsl(var(--crit))" }}
    >
      <span className="mr-auto">{texto}</span>
      <button className="btn btn-sec text-xs" onClick={onFechar}>
        Entendi
      </button>
    </p>
  );
}

export function alerta() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.value = 784;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.07, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.4);
    osc.start();
    osc.stop(ctx.currentTime + 0.42);
    setTimeout(() => ctx.close().catch(() => {}), 700);
  } catch {
    // som é um extra
  }
}
