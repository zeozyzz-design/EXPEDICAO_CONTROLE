"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ROTULO_PERFIL, abasDe } from "@/lib/domain";
import type { Perfil } from "@/lib/domain";
import { Marca, SeletorTema } from "@/components/Marca";

const CAMINHO: Record<string, string> = {
  fila: "/fila",
  "histórico": "/historico",
  indicadores: "/indicadores",
  auditoria: "/auditoria",
  usuarios: "/usuarios",
};

export function Navegacao({ perfil }: { perfil: Perfil }) {
  const atual = usePathname();
  const abas = abasDe(perfil.tipo);

  return (
    <header className="sticky z-30" style={{ top: "env(safe-area-inset-top, 0px)" }}>
      <div style={{ background: "hsl(var(--topbar))", borderBottom: "3px solid hsl(var(--topbar-line))" }}>
        <div className="gutter mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 py-3">
          <Marca />
          <div className="ml-auto flex flex-wrap items-center gap-3">
            <SeletorTema />
            <div className="text-right text-[11px] leading-tight" style={{ color: "hsl(var(--topbar-fg))" }}>
              <div className="font-semibold">{perfil.nome}</div>
              <div style={{ opacity: 0.8 }}>
                {ROTULO_PERFIL[perfil.tipo]}
                {perfil.transportadora ? ` · ${perfil.transportadora}` : ""}
              </div>
            </div>
            <form action="/api/sair" method="post">
              <button
                className="rounded border px-2 py-1 text-xs font-medium"
                style={{ color: "hsl(var(--topbar-fg))", borderColor: "hsl(var(--topbar-fg) / 0.35)" }}
              >
                Sair
              </button>
            </form>
          </div>
        </div>
      </div>
      <div className="border-b" style={{ background: "hsl(var(--card))" }}>
        <div className="gutter mx-auto flex max-w-6xl gap-1 py-1.5">
          {abas.map((a) => {
            const href = CAMINHO[a];
            const ativo = atual === href;
            return (
              <Link
                key={a}
                href={href}
                className="rounded px-3 py-1.5 text-sm font-medium capitalize"
                style={ativo ? { background: "hsl(var(--primary))", color: "hsl(var(--primary-fg))" } : undefined}
              >
                {a}
              </Link>
            );
          })}
        </div>
      </div>
    </header>
  );
}
