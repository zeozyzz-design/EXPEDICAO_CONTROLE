"use client";

import { useEffect, useState } from "react";

export type Tema = "sistema" | "claro" | "escuro";

export function aplicarTema(t: Tema) {
  const raiz = document.documentElement;
  if (t === "sistema") raiz.removeAttribute("data-theme");
  else raiz.setAttribute("data-theme", t === "escuro" ? "dark" : "light");
  try {
    localStorage.setItem("expedicao-tema", t);
  } catch {
    // preferência só nesta sessão
  }
}

export function lerTema(): Tema {
  try {
    const v = localStorage.getItem("expedicao-tema");
    if (v === "claro" || v === "escuro" || v === "sistema") return v;
  } catch {
    // padrão do sistema
  }
  return "sistema";
}

export function Marca() {
  return (
    <div className="flex items-center gap-3">
      <span className="wordmark text-[15px] leading-none" style={{ color: "hsl(var(--topbar-fg))" }}>
        IVECO GROUP
      </span>
      <span className="h-5 w-px" style={{ background: "hsl(var(--topbar-line))" }} />
      <span className="display text-sm font-semibold" style={{ color: "hsl(var(--topbar-fg))" }}>
        Controle de Expedição
      </span>
    </div>
  );
}

export function SeletorTema() {
  const [tema, setTema] = useState<Tema>("sistema");
  useEffect(() => setTema(lerTema()), []);

  return (
    <div className="flex items-center gap-0.5 rounded p-0.5" style={{ background: "rgba(255,255,255,.12)" }}>
      {(["claro", "escuro", "sistema"] as Tema[]).map((t) => (
        <button
          key={t}
          onClick={() => {
            setTema(t);
            aplicarTema(t);
          }}
          aria-pressed={tema === t}
          className="rounded px-2 py-1 text-[11px] font-semibold capitalize"
          style={tema === t ? { background: "hsl(var(--brand))", color: "#fff" } : { color: "hsl(var(--topbar-fg))" }}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

export function Topo({ children }: { children?: React.ReactNode }) {
  return (
    <div
      className="sticky z-30"
      style={{ top: "env(safe-area-inset-top, 0px)", background: "hsl(var(--topbar))", borderBottom: "3px solid hsl(var(--topbar-line))" }}
    >
      <div className="gutter mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 py-3">
        <Marca />
        <div className="ml-auto flex flex-wrap items-center gap-3">
          <SeletorTema />
          {children}
        </div>
      </div>
    </div>
  );
}
