"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { criarClienteNavegador } from "@/lib/supabase/client";
import { Topo } from "@/components/Marca";

export default function Entrar() {
  const router = useRouter();
  const supabase = criarClienteNavegador();
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [entrando, setEntrando] = useState(false);
  const [vazio, setVazio] = useState(false);

  useEffect(() => {
    supabase
      .from("perfis")
      .select("id", { count: "exact", head: true })
      .then(({ count, error }) => {
        if (!error && (count ?? 0) === 0) setVazio(true);
      });
  }, [supabase]);

  async function entrar(e: React.FormEvent) {
    e.preventDefault();
    setEntrando(true);
    setErro(null);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: senha });
    if (error) {
      setErro("E-mail ou senha não confere.");
      setEntrando(false);
      return;
    }
    router.push("/fila");
    router.refresh();
  }

  return (
    <div className="min-h-screen">
      <Topo />
      <main className="gutter mx-auto grid max-w-md gap-4 py-10">
        <h1 className="display text-xl font-bold">Entrar no painel</h1>
        <form className="cartao grid gap-3 p-4" onSubmit={entrar}>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="email">
              E-mail
            </label>
            <input id="email" type="email" className="campo" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" required />
          </div>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="senha">
              Senha
            </label>
            <input
              id="senha"
              type="password"
              className="campo"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              autoComplete="current-password"
              required
            />
          </div>
          {erro ? (
            <p className="text-sm" style={{ color: "hsl(var(--crit))" }}>
              {erro}
            </p>
          ) : null}
          <button className="btn btn-pri" disabled={entrando}>
            {entrando ? "Entrando…" : "Entrar"}
          </button>
          <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            Cada perfil enxerga só o que é do processo dele. Quem cria e reativa logins é a Celere.
          </p>
        </form>
        {vazio ? (
          <a className="btn btn-sec" href="/primeiro-acesso">
            Primeiro acesso: criar o login master da Celere
          </a>
        ) : null}
      </main>
    </div>
  );
}
