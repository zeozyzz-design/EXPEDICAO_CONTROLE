import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { criarClienteServidor } from "@/lib/supabase/server";

/**
 * Criação de login. Dois caminhos:
 *  - base vazia: cria o acesso master da Celere, sem exigir sessão;
 *  - base com perfis: exige sessão de um perfil Celere ativo.
 * A chave de serviço fica só aqui, no servidor.
 */
export async function POST(req: Request) {
  const { email, senha, nome, tipo, transportadora } = await req.json();

  if (!email || !senha || !nome || !tipo) {
    return NextResponse.json({ erro: "Faltam dados do login." }, { status: 400 });
  }
  if (String(senha).length < 8) {
    return NextResponse.json({ erro: "A senha precisa de pelo menos 8 caracteres." }, { status: 400 });
  }
  if (tipo === "transportadora" && !transportadora) {
    return NextResponse.json({ erro: "Escolha a transportadora deste login." }, { status: 400 });
  }

  const servico = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!servico) {
    return NextResponse.json({ erro: "SUPABASE_SERVICE_ROLE_KEY não está configurada no servidor." }, { status: 500 });
  }

  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, servico, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { count } = await admin.from("perfis").select("id", { count: "exact", head: true });
  const primeiro = (count ?? 0) === 0;

  if (primeiro) {
    if (tipo !== "celere") {
      return NextResponse.json({ erro: "O primeiro acesso do sistema precisa ser da Celere." }, { status: 400 });
    }
  } else {
    const supabase = await criarClienteServidor();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ erro: "Sessão expirada." }, { status: 401 });

    const { data: eu } = await admin.from("perfis").select("tipo, ativo").eq("id", user.id).single();
    if (!eu?.ativo || eu.tipo !== "celere") {
      return NextResponse.json({ erro: "Só a Celere cria logins." }, { status: 403 });
    }
  }

  const { data: criado, error: erroAuth } = await admin.auth.admin.createUser({
    email: String(email).trim().toLowerCase(),
    password: String(senha),
    email_confirm: true,
  });

  if (erroAuth || !criado.user) {
    const msg = erroAuth?.message?.includes("already") ? "Já existe um login com este e-mail." : "Não foi possível criar o login.";
    return NextResponse.json({ erro: msg }, { status: 400 });
  }

  const { error: erroPerfil } = await admin.from("perfis").insert({
    id: criado.user.id,
    nome: String(nome).trim(),
    tipo,
    transportadora: tipo === "transportadora" ? transportadora : null,
  });

  if (erroPerfil) {
    await admin.auth.admin.deleteUser(criado.user.id);
    return NextResponse.json({ erro: "O login foi criado mas o perfil falhou. Tente de novo." }, { status: 500 });
  }

  return NextResponse.json({ ok: true, id: criado.user.id });
}

/** Ativa ou desativa um login. Só a Celere. */
export async function PATCH(req: Request) {
  const { id, ativo } = await req.json();
  const servico = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!servico) return NextResponse.json({ erro: "Chave de serviço ausente." }, { status: 500 });

  const supabase = await criarClienteServidor();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ erro: "Sessão expirada." }, { status: 401 });

  const admin = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, servico, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { data: eu } = await admin.from("perfis").select("tipo, ativo").eq("id", user.id).single();
  if (!eu?.ativo || eu.tipo !== "celere") return NextResponse.json({ erro: "Só a Celere altera logins." }, { status: 403 });
  if (id === user.id) return NextResponse.json({ erro: "Você não pode desativar o próprio login." }, { status: 400 });

  const { error } = await admin.from("perfis").update({ ativo }).eq("id", id);
  if (error) return NextResponse.json({ erro: "Não foi possível alterar o login." }, { status: 500 });

  return NextResponse.json({ ok: true });
}
