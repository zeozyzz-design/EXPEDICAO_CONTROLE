"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { criarClienteNavegador } from "@/lib/supabase/client";
import { Topo } from "@/components/Marca";

export default function PrimeiroAcesso() {
  const router = useRouter();
  const supabase = criarClienteNavegador();
  const [email, setEmail] = useState("");
  const [nome, setNome] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);

  const valido = email.includes("@") && nome.trim().length >= 2 && senha.length >= 8;

  async function criar(e: React.FormEvent) {
    e.preventDefault();
    if (!valido) return;
    setSalvando(true);
    setErro(null);

    const res = await fetch("/api/usuarios", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, senha, nome, tipo: "celere" }),
    });
    const corpo = await res.json();

    if (!res.ok) {
      setErro(corpo.erro ?? "Não foi possível criar o acesso.");
      setSalvando(false);
      return;
    }

    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: senha });
    if (error) {
      setErro("Acesso criado. Entre com o e-mail e a senha que você acabou de definir.");
      setSalvando(false);
      return;
    }
    router.push("/fila");
    router.refresh();
  }

  return (
    <div className="min-h-screen">
      <Topo />
      <main className="gutter mx-auto grid max-w-md gap-4 py-10">
        <h1 className="display text-xl font-bold">Primeiro acesso</h1>
        <form className="cartao grid gap-3 p-4" onSubmit={criar}>
          <p className="text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
            Crie o acesso master da Celere. Depois dele, os logins da CEVA, das transportadoras e da gerência são criados na aba Usuários.
          </p>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="m-email">
              E-mail
            </label>
            <input id="m-email" type="email" className="campo" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="m-nome">
              Nome
            </label>
            <input id="m-nome" className="campo" value={nome} onChange={(e) => setNome(e.target.value)} required />
          </div>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="m-senha">
              Senha
            </label>
            <input
              id="m-senha"
              type="password"
              className="campo"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="mínimo 8 caracteres"
              required
            />
          </div>
          {erro ? (
            <p className="text-sm" style={{ color: "hsl(var(--crit))" }}>
              {erro}
            </p>
          ) : null}
          <button className="btn btn-pri" disabled={!valido || salvando}>
            {salvando ? "Criando…" : "Criar acesso master"}
          </button>
        </form>
      </main>
    </div>
  );
}
