"use client";

import { useState } from "react";
import { useDados } from "@/lib/dados";
import { ROTULO_PERFIL, TRANSPORTADORAS } from "@/lib/domain";
import type { PerfilTipo } from "@/lib/domain";

export default function Usuarios() {
  const d = useDados();
  const [email, setEmail] = useState("");
  const [nome, setNome] = useState("");
  const [tipo, setTipo] = useState<PerfilTipo>("transportadora");
  const [transportadora, setTransportadora] = useState<string>(TRANSPORTADORAS[0]);
  const [senha, setSenha] = useState("");
  const [salvando, setSalvando] = useState(false);
  const [recado, setRecado] = useState<{ tom: "ok" | "erro"; texto: string } | null>(null);

  const valido = email.includes("@") && nome.trim().length >= 2 && senha.length >= 8;

  async function criar() {
    setSalvando(true);
    setRecado(null);
    const res = await fetch("/api/usuarios", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, senha, nome, tipo, transportadora: tipo === "transportadora" ? transportadora : null }),
    });
    const corpo = await res.json();
    setSalvando(false);
    if (!res.ok) {
      setRecado({ tom: "erro", texto: corpo.erro ?? "Não foi possível criar o login." });
      return;
    }
    setRecado({ tom: "ok", texto: `Login de ${nome.trim()} criado. Passe a senha por um canal seguro — ela não aparece mais aqui.` });
    setEmail("");
    setNome("");
    setSenha("");
    await d.recarregar();
  }

  async function alternar(id: string, ativo: boolean) {
    const res = await fetch("/api/usuarios", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id, ativo }),
    });
    if (!res.ok) {
      const corpo = await res.json();
      setRecado({ tom: "erro", texto: corpo.erro ?? "Não foi possível alterar o login." });
      return;
    }
    await d.recarregar();
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <section className="cartao">
        <div className="border-b p-4">
          <h2 className="display text-base font-semibold">Logins do painel</h2>
          <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            Cada pessoa entra com o próprio e-mail e vê apenas o que é do processo dela. A Celere é o acesso master.
          </p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[520px] text-sm">
            <thead>
              <tr className="eyebrow border-b text-left text-[11px]" style={{ color: "hsl(var(--muted-fg))" }}>
                <th className="px-4 py-2 font-semibold">Nome</th>
                <th className="px-4 py-2 font-semibold">Perfil</th>
                <th className="px-4 py-2 font-semibold">Situação</th>
                <th className="px-4 py-2" />
              </tr>
            </thead>
            <tbody>
              {d.perfis
                .slice()
                .sort((a, b) => a.nome.localeCompare(b.nome))
                .map((p) => (
                  <tr key={p.id} className="border-b last:border-0">
                    <td className="px-4 py-2 font-medium">{p.nome}</td>
                    <td className="px-4 py-2" style={{ color: "hsl(var(--muted-fg))" }}>
                      {ROTULO_PERFIL[p.tipo]}
                      {p.transportadora ? ` · ${p.transportadora}` : ""}
                    </td>
                    <td className="px-4 py-2">
                      <span
                        className="rounded-sm px-1.5 py-0.5 text-[11px] font-semibold"
                        style={
                          p.ativo
                            ? { background: "hsl(var(--ok-bg))", color: "hsl(var(--ok))" }
                            : { background: "hsl(var(--muted))", color: "hsl(var(--muted-fg))" }
                        }
                      >
                        {p.ativo ? "ativo" : "inativo"}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-right">
                      {p.id === d.eu.id ? (
                        <span className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                          você
                        </span>
                      ) : (
                        <button className="btn btn-sec px-2 py-1 text-xs" onClick={() => alternar(p.id, !p.ativo)}>
                          {p.ativo ? "Desativar" : "Reativar"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="cartao p-4">
        <h2 className="display text-base font-semibold">Criar login</h2>
        <div className="mt-3 grid gap-3">
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="novo-email">
              E-mail
            </label>
            <input id="novo-email" type="email" className="campo" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="pessoa@empresa.com.br" />
          </div>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="novo-nome">
              Nome de quem usa
            </label>
            <input id="novo-nome" className="campo" value={nome} onChange={(e) => setNome(e.target.value)} />
          </div>
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="novo-tipo">
              Perfil
            </label>
            <select id="novo-tipo" className="campo" value={tipo} onChange={(e) => setTipo(e.target.value as PerfilTipo)}>
              {(["celere", "ceva", "transportadora", "gerencia"] as PerfilTipo[]).map((t) => (
                <option key={t} value={t}>
                  {ROTULO_PERFIL[t]}
                </option>
              ))}
            </select>
          </div>
          {tipo === "transportadora" ? (
            <div className="grid gap-1">
              <label className="text-xs font-medium" htmlFor="novo-transp">
                Transportadora
              </label>
              <select id="novo-transp" className="campo" value={transportadora} onChange={(e) => setTransportadora(e.target.value)}>
                {TRANSPORTADORAS.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          ) : null}
          <div className="grid gap-1">
            <label className="text-xs font-medium" htmlFor="nova-senha">
              Senha inicial
            </label>
            <input
              id="nova-senha"
              type="password"
              className="campo"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              placeholder="mínimo 8 caracteres"
            />
          </div>
          <button className="btn btn-pri" disabled={!valido || salvando} onClick={criar}>
            {salvando ? "Criando…" : "Criar login"}
          </button>
          {recado ? (
            <p className="text-xs" style={{ color: recado.tom === "ok" ? "hsl(var(--ok))" : "hsl(var(--crit))" }}>
              {recado.texto}
            </p>
          ) : null}
          <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            A senha é guardada pelo Supabase Auth, nunca pelo painel. Peça para a pessoa trocá-la no primeiro acesso.
          </p>
        </div>
      </section>
    </div>
  );
}
