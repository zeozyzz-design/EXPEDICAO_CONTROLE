import { redirect } from "next/navigation";
import { criarClienteServidor } from "@/lib/supabase/server";
import { ProvedorDados } from "@/lib/dados";
import { Navegacao } from "@/components/Navegacao";
import type { Perfil } from "@/lib/domain";

export default async function LayoutApp({ children }: { children: React.ReactNode }) {
  const supabase = await criarClienteServidor();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/entrar");

  const { data: perfil } = await supabase.from("perfis").select("*").eq("id", user.id).single();

  if (!perfil || !(perfil as Perfil).ativo) {
    return (
      <main className="gutter mx-auto grid max-w-md gap-3 py-16">
        <h1 className="display text-xl font-bold">Acesso sem perfil ativo</h1>
        <p className="text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
          Seu login existe, mas não tem perfil ativo no painel. Procure a Celere para liberar o acesso.
        </p>
        <form action="/api/sair" method="post">
          <button className="btn btn-sec">Sair</button>
        </form>
      </main>
    );
  }

  return (
    <ProvedorDados perfilInicial={perfil as Perfil}>
      <div className="min-h-screen">
        <Navegacao perfil={perfil as Perfil} />
        <main className="gutter mx-auto max-w-6xl py-4">{children}</main>
      </div>
    </ProvedorDados>
  );
}
