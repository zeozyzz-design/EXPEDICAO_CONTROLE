"use client";

import { Fragment, useMemo, useState } from "react";
import { useDados } from "@/lib/dados";
import {
  ETAPA_FINAL,
  PERIODOS,
  TRANSPORTADORAS,
  baixarCsv,
  carimbos,
  csv,
  dentroDoPeriodo,
  duracao,
  hora,
  mediana,
  minutosEntre,
} from "@/lib/domain";
import type { Evento, Ocorrencia, Periodo } from "@/lib/domain";

export default function Historico() {
  const d = useDados();
  const agora = Date.now();
  const [periodo, setPeriodo] = useState<Periodo>(30);
  const [busca, setBusca] = useState("");
  const [transp, setTransp] = useState("todas");
  const [situacao, setSituacao] = useState<"todas" | "aberto" | "finalizado" | "com-ocorrencia">("todas");
  const [aberto, setAberto] = useState<string | null>(null);

  const eventosPor = useMemo(() => {
    const m = new Map<string, Evento[]>();
    for (const e of d.eventos) {
      const arr = m.get(e.romaneio_id) ?? [];
      arr.push(e);
      m.set(e.romaneio_id, arr);
    }
    return m;
  }, [d.eventos]);

  const ocPor = useMemo(() => {
    const m = new Map<string, Ocorrencia[]>();
    for (const o of d.ocorrencias) {
      const arr = m.get(o.romaneio_id) ?? [];
      arr.push(o);
      m.set(o.romaneio_id, arr);
    }
    return m;
  }, [d.ocorrencias]);

  const linhas = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    return d.romaneios
      .filter((r) => dentroDoPeriodo(r.criado_em, periodo, agora))
      .map((r) => {
        const cps = carimbos(eventosPor.get(r.id) ?? []);
        const ini = cps.get(1) ?? r.criado_em;
        const fim = cps.get(ETAPA_FINAL);
        const ocs = ocPor.get(r.id) ?? [];
        const paradas = ocs.reduce(
          (s, o) => s + Math.max(0, ((o.fechada_em ? new Date(o.fechada_em).getTime() : agora) - new Date(o.aberta_em).getTime()) / 60000),
          0,
        );
        return { r, cps, ocs, paradas, lead: fim ? minutosEntre(ini, fim) : NaN, finalizado: r.etapa_atual >= ETAPA_FINAL };
      })
      .filter((l) => {
        if (termo && !l.r.numero.toLowerCase().includes(termo) && !l.r.transportadora.toLowerCase().includes(termo)) return false;
        if (transp !== "todas" && l.r.transportadora !== transp) return false;
        if (situacao === "aberto" && l.finalizado) return false;
        if (situacao === "finalizado" && !l.finalizado) return false;
        if (situacao === "com-ocorrencia" && l.ocs.length === 0) return false;
        return true;
      })
      .sort((a, b) => (a.r.criado_em < b.r.criado_em ? 1 : -1));
  }, [d.romaneios, eventosPor, ocPor, busca, transp, situacao, periodo, agora]);

  const leads = linhas.map((l) => l.lead).filter((n) => isFinite(n));
  const totalNotas = linhas.reduce((s, l) => s + l.r.qtd_notas, 0);
  const comOcorrencia = linhas.filter((l) => l.ocs.length > 0).length;

  function exportar() {
    const cab = [
      "Romaneio",
      "Transportadora",
      "Notas",
      "Situação",
      ...d.etapas.map((e) => `CP${e.cp} ${e.curto}`),
      ...d.etapas.filter((e) => e.cp > 1).map((e) => `CP${e.cp - 1}→CP${e.cp} (min)`),
      "Lead time (min)",
      "Ocorrências",
      "Parada total (min)",
    ];
    const corpo = linhas.map((l) => [
      l.r.numero,
      l.r.transportadora,
      l.r.qtd_notas,
      l.finalizado ? "Finalizado" : `Em aberto · CP${l.r.etapa_atual}`,
      ...d.etapas.map((e) => (l.cps.get(e.cp) ? hora(l.cps.get(e.cp)!) : "")),
      ...d.etapas.filter((e) => e.cp > 1).map((e) => {
        const a = l.cps.get(e.cp - 1);
        const b = l.cps.get(e.cp);
        return a && b ? Math.round(minutosEntre(a, b)) : "";
      }),
      isFinite(l.lead) ? Math.round(l.lead) : "",
      l.ocs.length,
      Math.round(l.paradas),
    ]);
    baixarCsv("historico-expedicao.csv", csv([cab, ...corpo]));
  }

  return (
    <section className="cartao">
      <div className="flex flex-wrap items-end gap-3 border-b p-4">
        <div className="mr-auto">
          <h2 className="display text-base font-semibold">Histórico de emissões</h2>
          <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            {linhas.length} {linhas.length === 1 ? "romaneio" : "romaneios"} · {totalNotas} notas · {comOcorrencia} com ocorrência · lead time mediano{" "}
            {leads.length ? duracao(mediana(leads)) : "—"}
          </p>
        </div>
        <div className="flex items-center gap-1 text-xs">
          {PERIODOS.map((p) => (
            <button
              key={p.dias}
              onClick={() => setPeriodo(p.dias)}
              aria-pressed={periodo === p.dias}
              className="rounded px-2 py-1 font-semibold"
              style={periodo === p.dias ? { background: "hsl(var(--brand))", color: "#fff" } : { color: "hsl(var(--muted-fg))" }}
            >
              {p.rotulo}
            </button>
          ))}
        </div>
        <label className="grid gap-1 text-xs">
          <span className="font-medium">Buscar</span>
          <input className="campo w-36 py-1.5" value={busca} onChange={(e) => setBusca(e.target.value)} placeholder="número" />
        </label>
        <label className="grid gap-1 text-xs">
          <span className="font-medium">Transportadora</span>
          <select className="campo w-32 py-1.5" value={transp} onChange={(e) => setTransp(e.target.value)}>
            <option value="todas">Todas</option>
            {TRANSPORTADORAS.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <label className="grid gap-1 text-xs">
          <span className="font-medium">Situação</span>
          <select className="campo w-36 py-1.5" value={situacao} onChange={(e) => setSituacao(e.target.value as typeof situacao)}>
            <option value="todas">Todas</option>
            <option value="aberto">Em aberto</option>
            <option value="finalizado">Finalizadas</option>
            <option value="com-ocorrencia">Com ocorrência</option>
          </select>
        </label>
        <button className="btn btn-sec text-xs" onClick={exportar} disabled={!linhas.length}>
          Exportar CSV
        </button>
      </div>

      {linhas.length === 0 ? (
        <p className="p-6 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
          Nenhuma emissão no período e nos filtros escolhidos. Amplie o período ou limpe a busca.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[820px] text-sm">
            <thead>
              <tr className="eyebrow border-b text-left text-[11px]" style={{ color: "hsl(var(--muted-fg))" }}>
                <th className="px-4 py-2 font-semibold">Romaneio</th>
                <th className="px-4 py-2 font-semibold">Transportadora</th>
                <th className="px-4 py-2 font-semibold">Notas</th>
                <th className="px-4 py-2 font-semibold">Lançado</th>
                <th className="px-4 py-2 font-semibold">Situação</th>
                <th className="px-4 py-2 font-semibold">Lead time</th>
                <th className="px-4 py-2 font-semibold">Parada</th>
                <th className="px-4 py-2 font-semibold">Ocorrências</th>
              </tr>
            </thead>
            <tbody>
              {linhas.map((l) => (
                <Fragment key={l.r.id}>
                  <tr className="cursor-pointer border-b last:border-0" onClick={() => setAberto(aberto === l.r.id ? null : l.r.id)}>
                    <td className="mono px-4 py-2 font-semibold">{l.r.numero}</td>
                    <td className="px-4 py-2">{l.r.transportadora}</td>
                    <td className="tnum px-4 py-2">{l.r.qtd_notas}</td>
                    <td className="mono tnum whitespace-nowrap px-4 py-2 text-xs">{hora(l.r.criado_em)}</td>
                    <td className="px-4 py-2">
                      <span
                        className="rounded-sm px-1.5 py-0.5 text-[11px] font-semibold"
                        style={
                          l.finalizado
                            ? { background: "hsl(var(--ok-bg))", color: "hsl(var(--ok))" }
                            : { background: "hsl(var(--muted))", color: "hsl(var(--muted-fg))" }
                        }
                      >
                        {l.finalizado ? "Finalizada" : `CP${l.r.etapa_atual}`}
                      </span>
                    </td>
                    <td className="tnum px-4 py-2">{isFinite(l.lead) ? duracao(l.lead) : "—"}</td>
                    <td className="tnum px-4 py-2" style={l.paradas > 0 ? { color: "hsl(var(--warn))" } : undefined}>
                      {l.paradas > 0 ? duracao(l.paradas) : "—"}
                    </td>
                    <td className="tnum px-4 py-2">{l.ocs.length || "—"}</td>
                  </tr>
                  {aberto === l.r.id ? (
                    <tr className="border-b last:border-0">
                      <td colSpan={8} className="px-4 py-3" style={{ background: "hsl(var(--background))" }}>
                        <div className="grid gap-4 sm:grid-cols-2">
                          <div>
                            <h3 className="eyebrow text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
                              Tempos por etapa
                            </h3>
                            <ol className="mt-2 grid gap-1">
                              {d.etapas.map((e) => {
                                const em = l.cps.get(e.cp);
                                const ant = l.cps.get(e.cp - 1);
                                const gasto = em && ant ? minutosEntre(ant, em) : NaN;
                                return (
                                  <li key={e.cp} className="grid grid-cols-[2.5rem_minmax(0,1fr)_auto] items-baseline gap-2 text-xs">
                                    <span className="mono" style={{ color: "hsl(var(--muted-fg))" }}>
                                      CP{e.cp}
                                    </span>
                                    <span style={em ? undefined : { color: "hsl(var(--muted-fg))" }}>
                                      {e.nome} <span style={{ color: "hsl(var(--muted-fg))" }}>· {e.setor}</span>
                                    </span>
                                    <span className="mono tnum" style={{ color: "hsl(var(--muted-fg))" }}>
                                      {em ? hora(em) : "—"}
                                      {isFinite(gasto) ? ` · ${duracao(gasto)}` : ""}
                                    </span>
                                  </li>
                                );
                              })}
                            </ol>
                            {l.r.anexo_nome ? (
                              <p className="mt-2 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                                Anexo: {l.r.anexo_nome}
                              </p>
                            ) : null}
                          </div>
                          <div>
                            <h3 className="eyebrow text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
                              Ocorrências
                            </h3>
                            {l.ocs.length === 0 ? (
                              <p className="mt-2 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                                Nenhuma ocorrência neste romaneio.
                              </p>
                            ) : (
                              <ul className="mt-2 grid gap-1.5">
                                {l.ocs.map((o) => (
                                  <li key={o.id} className="rounded border p-2 text-xs">
                                    <div className="font-semibold">{o.tipo}</div>
                                    {o.motivo ? <div>{o.motivo}</div> : null}
                                    <div className="mt-0.5" style={{ color: "hsl(var(--muted-fg))" }}>
                                      {o.responsavel}
                                      {o.chamado ? ` · chamado ${o.chamado}` : ""} ·{" "}
                                      {o.fechada_em
                                        ? `resolvida em ${duracao(minutosEntre(o.aberta_em, o.fechada_em))}`
                                        : `aberta há ${duracao((agora - new Date(o.aberta_em).getTime()) / 60000)}`}
                                    </div>
                                  </li>
                                ))}
                              </ul>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  ) : null}
                </Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
