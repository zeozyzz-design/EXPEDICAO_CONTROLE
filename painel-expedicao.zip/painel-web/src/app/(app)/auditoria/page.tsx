"use client";

import { useState } from "react";
import { useDados } from "@/lib/dados";
import { hora } from "@/lib/domain";

export default function Auditoria() {
  const d = useDados();
  const [conferindo, setConferindo] = useState(false);
  const [resultado, setResultado] = useState<Array<{ numero: string; cp: number; problema: string }> | null>(null);

  const nome = new Map(d.romaneios.map((r) => [r.id, r.numero]));

  const linhas = [
    ...d.eventos.map((e) => ({
      em: e.ocorrido_em,
      romaneio: nome.get(e.romaneio_id) ?? "—",
      oque: e.tipo === "estorno" ? `Estorno do CP${e.cp}` : `CP${e.cp} · ${d.etapas.find((x) => x.cp === e.cp)?.curto ?? ""}`,
      autor: e.autor_nome + (e.por_master ? " (pela Celere)" : ""),
      nota: e.nota ?? "",
      elo: e.hash ? e.hash.slice(0, 8) : "",
      estorno: e.tipo === "estorno",
    })),
    ...d.ocorrencias.map((o) => ({
      em: o.aberta_em,
      romaneio: nome.get(o.romaneio_id) ?? "—",
      oque: `Ocorrência aberta · ${o.tipo}`,
      autor: d.perfis.find((p) => p.id === o.aberta_por)?.nome ?? "—",
      nota: `responsável: ${o.responsavel}${o.chamado ? ` · chamado ${o.chamado}` : ""}`,
      elo: "",
      estorno: false,
    })),
    ...d.ocorrencias
      .filter((o) => o.fechada_em)
      .map((o) => ({
        em: o.fechada_em as string,
        romaneio: nome.get(o.romaneio_id) ?? "—",
        oque: `Ocorrência fechada · ${o.tipo}`,
        autor: d.perfis.find((p) => p.id === o.fechada_por)?.nome ?? "—",
        nota: "",
        elo: "",
        estorno: false,
      })),
  ].sort((a, b) => (a.em < b.em ? 1 : -1));

  return (
    <section className="cartao">
      <div className="flex flex-wrap items-start gap-3 border-b p-4">
        <div className="mr-auto">
          <h2 className="display text-base font-semibold">Linha do tempo bruta</h2>
          <p className="mt-0.5 max-w-[62ch] text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            A hora de cada evento é gravada pelo banco, não pelo navegador de quem registra. O banco recusa alterar ou apagar um evento: uma correção
            entra como estorno. Cada registro guarda o resumo do anterior, então mexer num evento antigo quebra a cadeia dos seguintes.
          </p>
        </div>
        <button
          className="btn btn-sec text-xs"
          disabled={conferindo || d.eventos.length === 0}
          onClick={async () => {
            setConferindo(true);
            const r = await d.verificarIntegridade();
            setConferindo(false);
            if (r) setResultado(r);
          }}
        >
          {conferindo ? "Conferindo…" : "Verificar integridade"}
        </button>
      </div>

      {resultado ? (
        <div
          className="border-b px-4 py-3 text-sm"
          style={
            resultado.length
              ? { background: "hsl(var(--crit-bg))", color: "hsl(var(--crit))" }
              : { background: "hsl(var(--ok-bg))", color: "hsl(var(--ok))" }
          }
        >
          {resultado.length ? (
            <>
              <strong>{resultado.length} evento(s) fora do lugar:</strong>{" "}
              {resultado.slice(0, 6).map((x) => `${x.numero} CP${x.cp} (${x.problema})`).join("; ")}
              {resultado.length > 6 ? "…" : ""}
            </>
          ) : (
            <>
              <strong>Cadeia íntegra.</strong> Os {d.eventos.length} eventos conferem com o que foi gravado; nenhum foi alterado depois.
            </>
          )}
        </div>
      ) : null}

      {linhas.length === 0 ? (
        <p className="p-6 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
          Nenhum evento registrado ainda.
        </p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead>
              <tr className="eyebrow border-b text-left text-[11px]" style={{ color: "hsl(var(--muted-fg))" }}>
                <th className="px-4 py-2 font-semibold">Quando</th>
                <th className="px-4 py-2 font-semibold">Romaneio</th>
                <th className="px-4 py-2 font-semibold">Evento</th>
                <th className="px-4 py-2 font-semibold">Quem registrou</th>
                <th className="px-4 py-2 font-semibold">Detalhe</th>
                <th className="px-4 py-2 font-semibold">Elo</th>
              </tr>
            </thead>
            <tbody>
              {linhas.slice(0, 400).map((l, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="mono tnum whitespace-nowrap px-4 py-2 text-xs">{hora(l.em)}</td>
                  <td className="mono whitespace-nowrap px-4 py-2">{l.romaneio}</td>
                  <td className="px-4 py-2" style={l.estorno ? { color: "hsl(var(--crit))" } : undefined}>
                    {l.oque}
                  </td>
                  <td className="whitespace-nowrap px-4 py-2" style={{ color: "hsl(var(--muted-fg))" }}>
                    {l.autor}
                  </td>
                  <td className="px-4 py-2" style={{ color: "hsl(var(--muted-fg))" }}>
                    {l.nota}
                  </td>
                  <td className="mono px-4 py-2 text-[10px]" style={{ color: "hsl(var(--muted-fg))" }}>
                    {l.elo}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
