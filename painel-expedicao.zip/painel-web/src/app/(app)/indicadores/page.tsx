"use client";

import { useMemo, useState } from "react";
import { useDados } from "@/lib/dados";
import {
  ETAPA_FINAL,
  PERIODOS,
  baixarCsv,
  csv,
  dentroDoPeriodo,
  diaCurto,
  duracao,
  hora,
  mediana,
  minutosEntre,
  percentil,
  semanaDe,
} from "@/lib/domain";
import type { Evento, Periodo } from "@/lib/domain";

function Tile({ rotulo, valor, nota }: { rotulo: string; valor: string; nota?: string }) {
  return (
    <div className="cartao p-4">
      <div className="eyebrow text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
        {rotulo}
      </div>
      <div className="display tnum mt-1 text-3xl leading-none" style={{ fontWeight: 700 }}>
        {valor}
      </div>
      {nota ? (
        <div className="mt-1 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
          {nota}
        </div>
      ) : null}
    </div>
  );
}

function Barra({ rotulo, valor, max, texto, cor }: { rotulo: string; valor: number; max: number; texto: string; cor: string }) {
  const pct = max > 0 && isFinite(valor) ? Math.max(2, Math.round((valor / max) * 100)) : 0;
  return (
    <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1 py-1.5">
      <div className="min-w-0 truncate text-sm">{rotulo}</div>
      <div className="tnum mono text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
        {texto}
      </div>
      <div className="col-span-2 h-2 rounded-sm" style={{ background: "hsl(var(--muted))" }}>
        <div className="h-2 rounded-sm" style={{ width: `${pct}%`, background: cor }} />
      </div>
    </div>
  );
}

export default function Indicadores() {
  const d = useDados();
  const agora = Date.now();
  const [periodo, setPeriodo] = useState<Periodo>(30);
  const [rascunho, setRascunho] = useState<Record<number, number> | null>(null);

  const romaneios = useMemo(() => d.romaneios.filter((r) => dentroDoPeriodo(r.criado_em, periodo, agora)), [d.romaneios, periodo, agora]);
  const idsNoPeriodo = useMemo(() => new Set(romaneios.map((r) => r.id)), [romaneios]);
  const ocorrencias = useMemo(() => d.ocorrencias.filter((o) => idsNoPeriodo.has(o.romaneio_id)), [d.ocorrencias, idsNoPeriodo]);

  const porRomaneio = useMemo(() => {
    const m = new Map<string, Evento[]>();
    for (const e of d.eventos) {
      if (!idsNoPeriodo.has(e.romaneio_id) || e.tipo !== "checkpoint") continue;
      const arr = m.get(e.romaneio_id) ?? [];
      arr.push(e);
      m.set(e.romaneio_id, arr);
    }
    return m;
  }, [d.eventos, idsNoPeriodo]);

  const cpsDe = (id: string) => {
    const m = new Map<number, string>();
    for (const e of porRomaneio.get(id) ?? []) {
      const a = m.get(e.cp);
      if (!a || e.ocorrido_em > a) m.set(e.cp, e.ocorrido_em);
    }
    return m;
  };

  const intervalos = new Map<number, number[]>();
  const leadTimes: number[] = [];
  for (const r of romaneios) {
    const cps = cpsDe(r.id);
    for (let cp = 2; cp <= ETAPA_FINAL; cp++) {
      const fim = cps.get(cp);
      const ini = cps.get(cp - 1);
      if (fim && ini) {
        const arr = intervalos.get(cp) ?? [];
        arr.push(minutosEntre(ini, fim));
        intervalos.set(cp, arr);
      }
    }
    const c1 = cps.get(1);
    const cf = cps.get(ETAPA_FINAL);
    if (c1 && cf) leadTimes.push(minutosEntre(c1, cf));
  }

  const abertas = ocorrencias.filter((o) => !o.fechada_em);
  const horasPorResp = new Map<string, number>();
  const contaPorTipo = new Map<string, number>();
  for (const o of ocorrencias) {
    const fim = o.fechada_em ? new Date(o.fechada_em).getTime() : agora;
    const min = Math.max(0, (fim - new Date(o.aberta_em).getTime()) / 60000);
    horasPorResp.set(o.responsavel, (horasPorResp.get(o.responsavel) ?? 0) + min);
    contaPorTipo.set(o.tipo, (contaPorTipo.get(o.tipo) ?? 0) + 1);
  }

  type Agregado = { total: number; fim: number; lead: number[]; transp: number[]; oc: number };
  const porTransp = new Map<string, Agregado>();
  for (const r of romaneios) {
    const acc = porTransp.get(r.transportadora) ?? { total: 0, fim: 0, lead: [], transp: [], oc: 0 };
    acc.total++;
    if (r.etapa_atual >= ETAPA_FINAL) acc.fim++;
    const cps = cpsDe(r.id);
    const c1 = cps.get(1);
    const c3 = cps.get(3);
    const cf = cps.get(ETAPA_FINAL);
    if (c1 && cf) acc.lead.push(minutosEntre(c1, cf));
    if (c3 && cf) acc.transp.push(minutosEntre(c3, cf));
    porTransp.set(r.transportadora, acc);
  }
  for (const o of ocorrencias) {
    const r = romaneios.find((x) => x.id === o.romaneio_id);
    const acc = r ? porTransp.get(r.transportadora) : undefined;
    if (acc) acc.oc++;
  }

  const semanas = new Map<string, number[]>();
  for (const r of romaneios) {
    const cps = cpsDe(r.id);
    const c1 = cps.get(1);
    const cf = cps.get(ETAPA_FINAL);
    if (!c1 || !cf) continue;
    const k = semanaDe(c1);
    const arr = semanas.get(k) ?? [];
    arr.push(minutosEntre(c1, cf));
    semanas.set(k, arr);
  }
  const tendencia = Array.from(semanas.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-12)
    .map(([k, v]) => ({ k, med: mediana(v), n: v.length }));

  const emAberto = romaneios.filter((r) => r.etapa_atual < ETAPA_FINAL);
  const hoje = new Date().toDateString();
  const lancadosHoje = d.romaneios.filter((r) => new Date(r.criado_em).toDateString() === hoje);
  const maxHoras = Math.max(1, ...Array.from(horasPorResp.values()));
  const maxTipo = Math.max(1, ...Array.from(contaPorTipo.values()));
  const maxIntervalo = Math.max(1, ...Array.from(intervalos.values()).map((v) => mediana(v) || 0));
  const maxTend = Math.max(1, ...tendencia.map((t) => t.med));
  const semDados = porRomaneio.size === 0;

  function exportarOcorrencias() {
    const nomes = new Map(d.romaneios.map((r) => [r.id, r.numero]));
    const cab = ["Romaneio", "Tipo", "Motivo", "Responsável", "Chamado", "Aberta em", "Fechada em", "Minutos"];
    const linhas = ocorrencias.map((o) => [
      nomes.get(o.romaneio_id) ?? "",
      o.tipo,
      o.motivo ?? "",
      o.responsavel,
      o.chamado ?? "",
      hora(o.aberta_em),
      o.fechada_em ? hora(o.fechada_em) : "",
      Math.round(((o.fechada_em ? new Date(o.fechada_em).getTime() : agora) - new Date(o.aberta_em).getTime()) / 60000),
    ]);
    baixarCsv("ocorrencias-expedicao.csv", csv([cab, ...linhas]));
  }

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="eyebrow mr-auto text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
          Período
        </span>
        <div className="flex items-center gap-1 text-xs">
          {PERIODOS.map((p) => (
            <button
              key={p.dias}
              onClick={() => setPeriodo(p.dias)}
              aria-pressed={periodo === p.dias}
              className="rounded px-2 py-1 font-semibold"
              style={periodo === p.dias ? { background: "hsl(var(--brand))", color: "#fff" } : { color: "hsl(var(--muted-fg))" }}
            >
              {p.rotulo}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Tile rotulo="Em aberto" valor={String(emAberto.length)} nota={`${emAberto.reduce((s, r) => s + r.qtd_notas, 0)} notas em andamento`} />
        <Tile rotulo="Lançados hoje" valor={String(lancadosHoje.length)} nota={`${lancadosHoje.reduce((s, r) => s + r.qtd_notas, 0)} notas`} />
        <Tile rotulo="Lead time mediano" valor={leadTimes.length ? duracao(mediana(leadTimes)) : "—"} nota="CP1 até CP6, finalizados" />
        <Tile rotulo="Ocorrências abertas" valor={String(abertas.length)} nota={`${ocorrencias.length} no período`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <section className="cartao p-4">
          <h2 className="display text-base font-semibold">Tempo por etapa</h2>
          <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            Mediana e percentil 90 de cada intervalo, contra a meta de SLA.
          </p>
          <div className="mt-3">
            {semDados ? (
              <p className="py-6 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
                Os tempos aparecem aqui assim que os primeiros checkpoints forem registrados.
              </p>
            ) : (
              d.etapas
                .filter((e) => e.cp > 1)
                .map((e) => {
                  const vals = intervalos.get(e.cp) ?? [];
                  const med = mediana(vals);
                  const meta = d.metas[e.cp];
                  const estourou = isFinite(med) && meta && med > meta;
                  return (
                    <Barra
                      key={e.cp}
                      rotulo={`CP${e.cp - 1} → CP${e.cp} · ${e.curto}`}
                      valor={isFinite(med) ? med : 0}
                      max={maxIntervalo}
                      texto={vals.length ? `${duracao(med)} · p90 ${duracao(percentil(vals, 90))} · meta ${meta ?? "—"}min` : "sem amostra"}
                      cor={estourou ? "hsl(var(--crit))" : "hsl(var(--brand))"}
                    />
                  );
                })
            )}
          </div>
        </section>

        <div className="grid gap-4">
          <section className="cartao p-4">
            <div className="flex items-start gap-3">
              <div className="mr-auto">
                <h2 className="display text-base font-semibold">Horas perdidas por empresa</h2>
                <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                  Tempo acumulado das ocorrências, pelo responsável marcado no registro.
                </p>
              </div>
              <button className="btn btn-sec text-xs" onClick={exportarOcorrencias} disabled={!ocorrencias.length}>
                CSV
              </button>
            </div>
            <div className="mt-3">
              {horasPorResp.size === 0 ? (
                <p className="py-4 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
                  Nenhuma ocorrência registrada no período.
                </p>
              ) : (
                Array.from(horasPorResp.entries())
                  .sort((a, b) => b[1] - a[1])
                  .map(([resp, min]) => <Barra key={resp} rotulo={resp} valor={min} max={maxHoras} texto={duracao(min)} cor="hsl(var(--warn))" />)
              )}
            </div>
          </section>

          <section className="cartao p-4">
            <h2 className="display text-base font-semibold">Ocorrências por tipo</h2>
            <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
              O que mais se repete, para atacar primeiro.
            </p>
            <div className="mt-3">
              {contaPorTipo.size === 0 ? (
                <p className="py-4 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
                  Nenhuma ocorrência registrada no período.
                </p>
              ) : (
                Array.from(contaPorTipo.entries())
                  .sort((a, b) => b[1] - a[1])
                  .map(([tipo, n]) => <Barra key={tipo} rotulo={tipo} valor={n} max={maxTipo} texto={`${n}×`} cor="hsl(var(--brand))" />)
              )}
            </div>
          </section>
        </div>
      </div>

      <section className="cartao p-4">
        <h2 className="display text-base font-semibold">Lead time por semana</h2>
        <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
          Mediana do CP1 ao CP6 das emissões finalizadas, pela semana em que entraram na fila.
        </p>
        {tendencia.length === 0 ? (
          <p className="py-6 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
            A tendência aparece quando houver emissões finalizadas: cada semana vira uma barra.
          </p>
        ) : (
          <div className="mt-4 flex items-end gap-2 overflow-x-auto pb-1" style={{ height: 160 }}>
            {tendencia.map((t) => (
              <div key={t.k} className="flex min-w-[48px] flex-1 flex-col items-center justify-end gap-1" style={{ height: "100%" }}>
                <span className="tnum mono text-[10px]" style={{ color: "hsl(var(--muted-fg))" }}>
                  {duracao(t.med)}
                </span>
                <div
                  className="w-full rounded-t"
                  style={{ height: `${Math.max(4, (t.med / maxTend) * 100)}%`, background: "hsl(var(--brand))" }}
                  title={`${t.n} ${t.n === 1 ? "emissão" : "emissões"}`}
                />
                <span className="tnum text-[10px]" style={{ color: "hsl(var(--muted-fg))" }}>
                  {diaCurto(t.k)}
                </span>
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="cartao">
        <div className="border-b p-4">
          <h2 className="display text-base font-semibold">Comparativo por transportadora</h2>
          <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            Mesma régua para todas: do recebimento do NOTFIS ao fim do descarregamento.
          </p>
        </div>
        {porTransp.size === 0 ? (
          <p className="p-6 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
            Nenhum romaneio no período.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[620px] text-sm">
              <thead>
                <tr className="eyebrow border-b text-left text-[11px]" style={{ color: "hsl(var(--muted-fg))" }}>
                  <th className="px-4 py-2 font-semibold">Transportadora</th>
                  <th className="px-4 py-2 font-semibold">Romaneios</th>
                  <th className="px-4 py-2 font-semibold">Finalizados</th>
                  <th className="px-4 py-2 font-semibold">Lead time mediano</th>
                  <th className="px-4 py-2 font-semibold">CP3 → CP6 mediano</th>
                  <th className="px-4 py-2 font-semibold">Ocorrências</th>
                </tr>
              </thead>
              <tbody>
                {Array.from(porTransp.entries())
                  .sort((a, b) => b[1].total - a[1].total)
                  .map(([t, v]) => (
                    <tr key={t} className="border-b last:border-0">
                      <td className="px-4 py-2 font-medium">{t}</td>
                      <td className="tnum px-4 py-2">{v.total}</td>
                      <td className="tnum px-4 py-2">{v.fim}</td>
                      <td className="tnum px-4 py-2">{v.lead.length ? duracao(mediana(v.lead)) : "—"}</td>
                      <td className="tnum px-4 py-2">{v.transp.length ? duracao(mediana(v.transp)) : "—"}</td>
                      <td className="tnum px-4 py-2">{v.oc}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {d.eu.tipo === "celere" ? (
        <section className="cartao p-4">
          <h2 className="display text-base font-semibold">Metas de SLA</h2>
          <p className="mt-0.5 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
            Minutos esperados em cada intervalo. É esta meta que pinta a fila e mede a aderência. A meta anterior fica no histórico, com a data em que
            saiu de vigência.
          </p>
          <div className="mt-3 flex flex-wrap gap-3">
            {d.etapas
              .filter((e) => e.cp > 1)
              .map((e) => (
                <label key={e.cp} className="grid gap-1 text-xs">
                  <span className="font-medium">
                    CP{e.cp - 1} → CP{e.cp}
                  </span>
                  <input
                    className="campo w-28"
                    inputMode="numeric"
                    value={String((rascunho ?? d.metas)[e.cp] ?? "")}
                    onChange={(ev) => setRascunho({ ...(rascunho ?? d.metas), [e.cp]: Number(ev.target.value.replace(/\D/g, "")) || 0 })}
                  />
                </label>
              ))}
          </div>
          <div className="mt-3 flex gap-2">
            <button
              className="btn btn-pri"
              disabled={!rascunho}
              onClick={async () => {
                if (!rascunho) return;
                for (const [cp, min] of Object.entries(rascunho)) {
                  if (min > 0 && d.metas[Number(cp)] !== min) await d.definirMeta(Number(cp), min);
                }
                setRascunho(null);
              }}
            >
              Salvar metas
            </button>
            <button className="btn btn-sec" disabled={!rascunho} onClick={() => setRascunho(null)}>
              Descartar
            </button>
          </div>
        </section>
      ) : null}
    </div>
  );
}
