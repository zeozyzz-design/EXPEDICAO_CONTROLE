"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useDados } from "@/lib/dados";
import {
  ETAPA_FINAL,
  MOTIVOS_EMISSAO,
  RESPONSAVEIS,
  TIPO_EMISSAO_PARADA,
  TRANSPORTADORAS,
  carimbos,
  duracao,
  faixaSla,
  hora,
  minutosEntre,
  podeRegistrar,
  setorAtual,
} from "@/lib/domain";
import type { EmpresaResp, Evento, Ocorrencia, Romaneio } from "@/lib/domain";
import { Aviso, Chip, Modal, alerta } from "@/components/Comuns";

export default function Fila() {
  const d = useDados();
  const [agora, setAgora] = useState(() => Date.now());
  const [verFinalizados, setVerFinalizados] = useState(false);
  const [busca, setBusca] = useState("");
  const [soAtrasados, setSoAtrasados] = useState(false);
  const [aberto, setAberto] = useState<string | null>(null);
  const [novo, setNovo] = useState(false);
  const [confirmar, setConfirmar] = useState<{ r: Romaneio; cp: number } | null>(null);
  const [ocorrenciaDe, setOcorrenciaDe] = useState<{ r: Romaneio; emissao: boolean } | null>(null);
  const [chegaram, setChegaram] = useState(0);
  const conhecidos = useRef<Set<string> | null>(null);
  const atrasadosVistos = useRef<Set<string>>(new Set());

  useEffect(() => {
    const t = setInterval(() => setAgora(Date.now()), 20000);
    return () => clearInterval(t);
  }, []);

  const eventosPor = useMemo(() => {
    const m = new Map<string, Evento[]>();
    for (const e of d.eventos) {
      const arr = m.get(e.romaneio_id) ?? [];
      arr.push(e);
      m.set(e.romaneio_id, arr);
    }
    for (const [, arr] of m) arr.sort((a, b) => (a.ocorrido_em < b.ocorrido_em ? -1 : 1));
    return m;
  }, [d.eventos]);

  const ocorrenciasPor = useMemo(() => {
    const m = new Map<string, Ocorrencia[]>();
    for (const o of d.ocorrencias) {
      const arr = m.get(o.romaneio_id) ?? [];
      arr.push(o);
      m.set(o.romaneio_id, arr);
    }
    return m;
  }, [d.ocorrencias]);

  useEffect(() => {
    if (!d.pronto) return;
    const ids = new Set(d.romaneios.map((r) => r.id));
    if (conhecidos.current === null) {
      conhecidos.current = ids;
      return;
    }
    let novos = 0;
    for (const id of ids) if (!conhecidos.current.has(id)) novos++;
    conhecidos.current = ids;
    if (novos > 0 && d.eu.tipo !== "ceva") {
      setChegaram((n) => n + novos);
      alerta();
    }
  }, [d.romaneios, d.pronto, d.eu.tipo]);

  const paradoDe = (r: Romaneio) => {
    const evs = (eventosPor.get(r.id) ?? []).filter((e) => e.tipo === "checkpoint");
    const desde = evs.length ? evs[evs.length - 1].ocorrido_em : r.criado_em;
    return Math.max(0, (agora - new Date(desde).getTime()) / 60000);
  };

  const estourou = (r: Romaneio) => {
    const prox = Math.min(ETAPA_FINAL, r.etapa_atual + 1);
    const meta = d.metas[prox];
    return !!meta && paradoDe(r) > meta;
  };

  const ordenar = (lista: Romaneio[]) =>
    lista.slice().sort((a, b) => {
      const ultimo = (r: Romaneio) => {
        const evs = (eventosPor.get(r.id) ?? []).filter((e) => e.tipo === "checkpoint");
        return new Date(evs.length ? evs[evs.length - 1].ocorrido_em : r.criado_em).getTime();
      };
      return ultimo(a) - ultimo(b);
    });

  const emAberto = ordenar(d.romaneios.filter((r) => r.etapa_atual < ETAPA_FINAL));
  const finalizados = ordenar(d.romaneios.filter((r) => r.etapa_atual >= ETAPA_FINAL)).reverse();
  const atrasados = emAberto.filter(estourou);

  useEffect(() => {
    let novos = 0;
    for (const r of atrasados)
      if (!atrasadosVistos.current.has(r.id)) {
        atrasadosVistos.current.add(r.id);
        novos++;
      }
    for (const id of Array.from(atrasadosVistos.current)) if (!atrasados.some((r) => r.id === id)) atrasadosVistos.current.delete(id);
    if (novos > 0) alerta();
  }, [atrasados]);

  const termo = busca.trim().toLowerCase();
  const visiveis = (verFinalizados ? finalizados : soAtrasados ? atrasados : emAberto).filter(
    (r) => !termo || r.numero.toLowerCase().includes(termo) || r.transportadora.toLowerCase().includes(termo),
  );

  if (!d.pronto) return <p className="text-sm" style={{ color: "hsl(var(--muted-fg))" }}>Carregando a fila…</p>;

  return (
    <>
      {d.erro ? <Aviso texto={d.erro} onFechar={d.limparErro} /> : null}

      {chegaram > 0 ? (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded border p-3" style={{ background: "hsl(var(--warn-bg))", borderColor: "hsl(var(--warn))" }}>
          <span className="text-sm font-semibold" style={{ color: "hsl(var(--warn))" }}>
            {chegaram === 1 ? "1 romaneio novo entrou na fila" : `${chegaram} romaneios novos entraram na fila`}
          </span>
          <button className="btn btn-sec ml-auto" onClick={() => setChegaram(0)}>
            Ciente
          </button>
        </div>
      ) : null}

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div className="flex rounded border p-0.5">
          <button
            className="rounded px-3 py-1.5 text-sm font-medium"
            style={!verFinalizados ? { background: "hsl(var(--primary))", color: "hsl(var(--primary-fg))" } : undefined}
            onClick={() => setVerFinalizados(false)}
          >
            Em aberto ({emAberto.length})
          </button>
          <button
            className="rounded px-3 py-1.5 text-sm font-medium"
            style={verFinalizados ? { background: "hsl(var(--primary))", color: "hsl(var(--primary-fg))" } : undefined}
            onClick={() => setVerFinalizados(true)}
          >
            Finalizados ({finalizados.length})
          </button>
        </div>
        {!verFinalizados && atrasados.length > 0 ? (
          <button
            className="rounded border px-3 py-1.5 text-sm font-semibold"
            style={
              soAtrasados
                ? { background: "hsl(var(--crit))", color: "#fff", borderColor: "hsl(var(--crit))" }
                : { color: "hsl(var(--crit))", borderColor: "hsl(var(--crit))" }
            }
            onClick={() => setSoAtrasados(!soAtrasados)}
          >
            Fora do SLA ({atrasados.length})
          </button>
        ) : null}
        <input className="campo w-40 py-1.5" placeholder="Buscar romaneio" value={busca} onChange={(e) => setBusca(e.target.value)} />
        {d.eu.tipo === "ceva" || d.eu.tipo === "celere" ? (
          <button className="btn btn-pri ml-auto" onClick={() => setNovo(true)}>
            Lançar romaneio
          </button>
        ) : null}
      </div>

      {visiveis.length === 0 ? (
        <div className="cartao p-6">
          <h2 className="display text-base font-semibold">{verFinalizados ? "Nenhuma emissão finalizada ainda" : "A fila em aberto está vazia"}</h2>
          <p className="mt-1 max-w-[60ch] text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
            {verFinalizados
              ? "Um romaneio sai daqui e entra nesta lista quando o fim do descarregamento é registrado."
              : "Assim que a CEVA enviar um romaneio — número, transportadora, quantidade de notas e a planilha de detalhamento — ele aparece aqui sozinho, com alerta para quem estiver com a tela aberta."}
          </p>
        </div>
      ) : (
        <div className="grid gap-1.5">
          <div className="eyebrow hidden gap-3 px-3 text-[10px] font-semibold sm:grid sm:grid-cols-[minmax(0,1.2fr)_6rem_6rem_6rem_3.5rem_4.5rem_6rem_12rem]" style={{ color: "hsl(var(--muted-fg))" }}>
            <span>Status</span>
            <span>Setor</span>
            <span>Romaneio</span>
            <span>Transportadora</span>
            <span>Notas</span>
            <span>Parado</span>
            <span>Anexo</span>
            <span className="text-right">Próximo passo</span>
          </div>
          {visiveis.map((r) => (
            <LinhaFila
              key={r.id}
              r={r}
              agora={agora}
              eventos={eventosPor.get(r.id) ?? []}
              ocorrencias={ocorrenciasPor.get(r.id) ?? []}
              expandido={aberto === r.id}
              parado={paradoDe(r)}
              onExpandir={() => setAberto(aberto === r.id ? null : r.id)}
              onPedirCheckpoint={(cp) => setConfirmar({ r, cp })}
              onOcorrencia={(emissao) => setOcorrenciaDe({ r, emissao })}
            />
          ))}
        </div>
      )}

      <p className="mt-6 max-w-[70ch] text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
        A hora de cada checkpoint é gravada pelo banco de dados no momento do registro, nunca pelo relógio de quem clica. Os registros não podem ser
        editados nem apagados: uma correção entra como estorno, e cada evento guarda o resumo do anterior.
      </p>

      {novo ? <NovoRomaneio onFechar={() => setNovo(false)} /> : null}
      {confirmar ? (
        <ConfirmarCheckpoint
          r={confirmar.r}
          cp={confirmar.cp}
          onFechar={() => setConfirmar(null)}
          onOcorrencia={() => {
            const alvo = confirmar.r;
            const emissao = confirmar.cp === 2 && d.eu.tipo === "celere";
            setConfirmar(null);
            setOcorrenciaDe({ r: alvo, emissao });
          }}
        />
      ) : null}
      {ocorrenciaDe ? <NovaOcorrencia r={ocorrenciaDe.r} emissao={ocorrenciaDe.emissao} onFechar={() => setOcorrenciaDe(null)} /> : null}
    </>
  );
}

function BotaoAnexo({ r }: { r: Romaneio }) {
  const d = useDados();
  const [baixando, setBaixando] = useState(false);
  if (!r.anexo_path) return <span className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>—</span>;

  return (
    <button
      className="btn btn-sec px-2 py-1 text-xs"
      disabled={baixando}
      onClick={async (e) => {
        e.stopPropagation();
        setBaixando(true);
        const url = await d.urlAnexo(r.anexo_path!);
        setBaixando(false);
        if (url) window.open(url, "_blank", "noopener");
      }}
    >
      {baixando ? "Abrindo…" : "Baixar anexo"}
    </button>
  );
}

function LinhaFila(props: {
  r: Romaneio;
  agora: number;
  parado: number;
  eventos: Evento[];
  ocorrencias: Ocorrencia[];
  expandido: boolean;
  onExpandir: () => void;
  onPedirCheckpoint: (cp: number) => void;
  onOcorrencia: (emissao: boolean) => void;
}) {
  const d = useDados();
  const { r, agora, parado, eventos, ocorrencias, expandido } = props;
  const [justificando, setJustificando] = useState(false);
  const [justificativa, setJustificativa] = useState("");

  const cps = carimbos(eventos);
  const finalizado = r.etapa_atual >= ETAPA_FINAL;
  const proximo = Math.min(ETAPA_FINAL, r.etapa_atual + 1);
  const etapaProxima = d.etapas.find((e) => e.cp === proximo);
  const abertas = ocorrencias.filter((o) => !o.fechada_em);
  const meta = d.metas[proximo];
  const tom = finalizado ? "neutro" : abertas.length ? "crit" : faixaSla(parado, meta);
  const setor = setorAtual(r, d.etapas);
  const podeProximo = !finalizado && podeRegistrar(d.eu, etapaProxima, r);
  const souLeitura = d.eu.tipo === "gerencia" || d.eu.tipo === "ceva";
  const status = finalizado ? "Finalizado" : abertas.length ? `Parado · ${abertas[0].tipo}` : `Aguardando CP${proximo} · ${etapaProxima?.curto ?? ""}`;

  return (
    <article className="cartao">
      <div
        className="grid cursor-pointer grid-cols-2 items-center gap-x-3 gap-y-1 p-3 sm:grid-cols-[minmax(0,1.2fr)_6rem_6rem_6rem_3.5rem_4.5rem_6rem_12rem]"
        onClick={props.onExpandir}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && props.onExpandir()}
      >
        <div className="col-span-2 min-w-0 sm:col-span-1">
          <Chip tom={finalizado ? "ok" : abertas.length ? "crit" : "marca"}>{status}</Chip>
        </div>
        <div className="text-sm">{finalizado ? "—" : setor === "Transportadora" ? r.transportadora : setor}</div>
        <div className="mono text-sm font-semibold">{r.numero}</div>
        <div className="text-sm">{r.transportadora}</div>
        <div className="tnum text-sm">{r.qtd_notas}</div>
        <div className="tnum mono text-sm" style={{ color: tom === "neutro" ? undefined : `hsl(var(--${tom}))` }}>
          {finalizado ? "—" : duracao(parado)}
        </div>
        <div className="flex sm:col-span-1">
          <BotaoAnexo r={r} />
        </div>
        <div className="col-span-2 flex justify-end sm:col-span-1" onClick={(e) => e.stopPropagation()}>
          {finalizado ? (
            <span className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
              concluído
            </span>
          ) : podeProximo ? (
            <button className="btn btn-pri w-full" onClick={() => props.onPedirCheckpoint(proximo)}>
              Registrar CP{proximo}
            </button>
          ) : (
            <span className="text-right text-[11px] leading-tight" style={{ color: "hsl(var(--muted-fg))" }}>
              com {etapaProxima?.setor === "Transportadora" ? r.transportadora : etapaProxima?.setor}
            </span>
          )}
        </div>
      </div>

      {expandido ? (
        <div className="grid gap-4 border-t p-3 sm:grid-cols-[minmax(0,1fr)_17rem]">
          <div>
            <h3 className="eyebrow text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
              Linha do tempo
            </h3>
            <ol className="mt-2 grid gap-1">
              {d.etapas.map((e) => {
                const em = cps.get(e.cp);
                const ant = cps.get(e.cp - 1);
                const gasto = em && ant ? minutosEntre(ant, em) : NaN;
                return (
                  <li key={e.cp} className="grid grid-cols-[2.5rem_minmax(0,1fr)_auto] items-baseline gap-2 text-sm">
                    <span className="mono text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                      CP{e.cp}
                    </span>
                    <span style={em ? undefined : { color: "hsl(var(--muted-fg))" }}>
                      {e.nome} <span style={{ color: "hsl(var(--muted-fg))" }}>· {e.setor}</span>
                    </span>
                    <span className="mono tnum text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                      {em ? hora(em) : "—"}
                      {isFinite(gasto) ? ` · ${duracao(gasto)}` : ""}
                    </span>
                  </li>
                );
              })}
            </ol>
            <p className="mt-3 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
              Enviado em {hora(r.criado_em)}
              {r.anexo_nome ? ` · anexo: ${r.anexo_nome}` : ""}
            </p>
          </div>

          <div className="grid content-start gap-2">
            {ocorrencias.length ? (
              <div className="grid gap-1">
                <h3 className="eyebrow text-[11px] font-semibold" style={{ color: "hsl(var(--muted-fg))" }}>
                  Ocorrências
                </h3>
                {ocorrencias.map((o) => (
                  <div key={o.id} className="rounded border p-2 text-xs">
                    <div className="font-semibold">{o.tipo}</div>
                    {o.motivo ? <div>{o.motivo}</div> : null}
                    {o.descricao ? <div style={{ color: "hsl(var(--muted-fg))" }}>{o.descricao}</div> : null}
                    <div className="mt-1" style={{ color: "hsl(var(--muted-fg))" }}>
                      responsável: {o.responsavel}
                      {o.chamado ? ` · chamado ${o.chamado}` : ""} ·{" "}
                      {o.fechada_em
                        ? `resolvida em ${duracao(minutosEntre(o.aberta_em, o.fechada_em))}`
                        : `aberta há ${duracao((agora - new Date(o.aberta_em).getTime()) / 60000)}`}
                    </div>
                    {!o.fechada_em && !souLeitura ? (
                      <button className="btn btn-sec mt-2 w-full py-1" onClick={() => d.fecharOcorrencia(o.id)}>
                        Fechar ocorrência
                      </button>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : null}

            {!finalizado ? (
              <button className="btn btn-pri" disabled={!podeProximo} onClick={() => props.onPedirCheckpoint(proximo)}>
                Registrar CP{proximo} · {etapaProxima?.curto}
              </button>
            ) : null}
            {!finalizado && !podeProximo ? (
              <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
                Este checkpoint é da {etapaProxima?.setor === "Transportadora" ? `transportadora ${r.transportadora}` : etapaProxima?.setor}.
              </p>
            ) : null}

            {d.eu.tipo === "celere" && r.etapa_atual === 1 ? (
              <button className="btn btn-sec" onClick={() => props.onOcorrencia(true)}>
                A emissão parou
              </button>
            ) : null}

            {!souLeitura ? (
              <button className="btn btn-sec" onClick={() => props.onOcorrencia(false)}>
                Registrar ocorrência
              </button>
            ) : null}

            {r.etapa_atual > 1 && podeRegistrar(d.eu, d.etapas.find((e) => e.cp === r.etapa_atual), r) && !souLeitura ? (
              justificando ? (
                <div className="grid gap-2">
                  <label className="text-xs font-medium" htmlFor={`just-${r.id}`}>
                    Por que o CP{r.etapa_atual} está sendo estornado?
                  </label>
                  <textarea id={`just-${r.id}`} className="campo" rows={2} value={justificativa} onChange={(e) => setJustificativa(e.target.value)} />
                  <div className="flex gap-2">
                    <button
                      className="btn btn-sec"
                      disabled={justificativa.trim().length < 4}
                      onClick={async () => {
                        await d.estornar(r.id, r.etapa_atual, justificativa.trim());
                        setJustificativa("");
                        setJustificando(false);
                      }}
                    >
                      Confirmar estorno
                    </button>
                    <button className="btn btn-sec" onClick={() => setJustificando(false)}>
                      Cancelar
                    </button>
                  </div>
                </div>
              ) : (
                <button className="btn btn-sec" style={{ color: "hsl(var(--muted-fg))" }} onClick={() => setJustificando(true)}>
                  Estornar CP{r.etapa_atual}
                </button>
              )
            ) : null}
          </div>
        </div>
      ) : null}
    </article>
  );
}

function ConfirmarCheckpoint({ r, cp, onFechar, onOcorrencia }: { r: Romaneio; cp: number; onFechar: () => void; onOcorrencia: () => void }) {
  const d = useDados();
  const [nota, setNota] = useState("");
  const [enviando, setEnviando] = useState(false);
  const etapa = d.etapas.find((e) => e.cp === cp);
  const proprio =
    (etapa?.setor === "CEVA" && d.eu.tipo === "ceva") ||
    (etapa?.setor === "Celere" && d.eu.tipo === "celere") ||
    (etapa?.setor === "Transportadora" && d.eu.tipo === "transportadora");

  return (
    <Modal titulo={`Registrar CP${cp}`} onFechar={onFechar}>
      <div className="rounded border p-3">
        <div className="display text-lg font-semibold">{etapa?.nome}</div>
        <div className="mt-1 text-sm" style={{ color: "hsl(var(--muted-fg))" }}>
          Romaneio <span className="mono font-semibold" style={{ color: "hsl(var(--foreground))" }}>{r.numero}</span> · {r.transportadora} ·{" "}
          {r.qtd_notas} notas
        </div>
        <div className="mt-2 grid gap-1 text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
          <div>A hora será gravada pelo servidor no instante da confirmação.</div>
          <div>
            Registrado por: {d.eu.nome}
          </div>
        </div>
      </div>

      {!proprio ? (
        <p className="rounded border p-2 text-xs" style={{ background: "hsl(var(--warn-bg))", borderColor: "hsl(var(--warn))", color: "hsl(var(--warn))" }}>
          Esta etapa é da {etapa?.setor === "Transportadora" ? `transportadora ${r.transportadora}` : etapa?.setor}. O registro fica marcado na auditoria
          como feito pela Celere em nome dela.
        </p>
      ) : null}

      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="nota-cp">
          Observação (opcional)
        </label>
        <input id="nota-cp" className="campo" value={nota} onChange={(e) => setNota(e.target.value)} placeholder="ex.: doca 3, motorista já na portaria" />
      </div>

      <button
        className="btn btn-pri w-full py-3 text-base"
        disabled={enviando}
        onClick={async () => {
          setEnviando(true);
          const ok = await d.registrarCheckpoint(r.id, cp, nota.trim() || undefined);
          if (ok) onFechar();
          else setEnviando(false);
        }}
      >
        {enviando ? "Gravando…" : `Confirmar CP${cp} agora`}
      </button>
      <button className="btn btn-sec" onClick={onOcorrencia}>
        Não consegui — abrir ocorrência
      </button>
      <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
        Depois de gravado, o checkpoint não pode ser editado: só estornado, com justificativa.
      </p>
    </Modal>
  );
}

function NovoRomaneio({ onFechar }: { onFechar: () => void }) {
  const d = useDados();
  const [numero, setNumero] = useState("");
  const [transportadora, setTransportadora] = useState<string>(TRANSPORTADORAS[0]);
  const [qtdNotas, setQtdNotas] = useState("");
  const [arquivo, setArquivo] = useState<File | null>(null);
  const [salvando, setSalvando] = useState(false);
  const valido = numero.trim().length > 0 && Number(qtdNotas) > 0;

  return (
    <Modal titulo="Romaneio fechado e enviado" onFechar={onFechar}>
      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="numero">
          Número do romaneio
        </label>
        <input id="numero" className="campo" value={numero} onChange={(e) => setNumero(e.target.value)} placeholder="ex.: 48219" />
      </div>
      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="transp">
          Transportadora
        </label>
        <select id="transp" className="campo" value={transportadora} onChange={(e) => setTransportadora(e.target.value)}>
          {TRANSPORTADORAS.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>
      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="qtd">
          Quantidade de notas
        </label>
        <input id="qtd" className="campo" inputMode="numeric" value={qtdNotas} onChange={(e) => setQtdNotas(e.target.value.replace(/\D/g, ""))} placeholder="ex.: 32" />
      </div>
      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="anexo">
          Planilha com o detalhamento das notas
        </label>
        <input id="anexo" type="file" className="campo" onChange={(e) => setArquivo(e.target.files?.[0] ?? null)} />
        <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
          O arquivo fica disponível para download na fila; o sistema não lê as notas dele.
        </p>
      </div>
      <div className="flex justify-end gap-2">
        <button className="btn btn-sec" onClick={onFechar}>
          Cancelar
        </button>
        <button
          className="btn btn-pri"
          disabled={!valido || salvando}
          onClick={async () => {
            setSalvando(true);
            const ok = await d.lancarRomaneio({ numero, transportadora, qtdNotas: Number(qtdNotas), arquivo });
            if (ok) onFechar();
            else setSalvando(false);
          }}
        >
          {salvando ? "Enviando…" : "Enviar para a fila"}
        </button>
      </div>
    </Modal>
  );
}

function NovaOcorrencia({ r, emissao, onFechar }: { r: Romaneio; emissao: boolean; onFechar: () => void }) {
  const d = useDados();
  const inicial = emissao ? TIPO_EMISSAO_PARADA : d.tipos[1]?.nome ?? d.tipos[0]?.nome ?? "Outro";
  const [tipo, setTipo] = useState(inicial);
  const def = d.tipos.find((t) => t.nome === tipo);
  const [responsavel, setResponsavel] = useState<EmpresaResp>(def?.responsavel ?? "Celere");
  const [motivo, setMotivo] = useState(MOTIVOS_EMISSAO[0]);
  const [chamado, setChamado] = useState("");
  const [descricao, setDescricao] = useState("");
  const [salvando, setSalvando] = useState(false);

  const exigeChamado = !!def?.exige_chamado;
  const valido = (!exigeChamado || chamado.trim().length > 0) && (tipo !== "Outro" || descricao.trim().length > 3);

  return (
    <Modal titulo={emissao ? `Emissão parada · romaneio ${r.numero}` : `Ocorrência no romaneio ${r.numero}`} onFechar={onFechar}>
      {emissao ? (
        <div className="grid gap-1">
          <label className="text-xs font-medium" htmlFor="motivo">
            O que travou a emissão
          </label>
          <select id="motivo" className="campo" value={motivo} onChange={(e) => setMotivo(e.target.value)}>
            {MOTIVOS_EMISSAO.map((m) => (
              <option key={m} value={m}>
                {m}
              </option>
            ))}
          </select>
        </div>
      ) : (
        <div className="grid gap-1">
          <label className="text-xs font-medium" htmlFor="tipo-oc">
            Tipo
          </label>
          <select
            id="tipo-oc"
            className="campo"
            value={tipo}
            onChange={(e) => {
              setTipo(e.target.value);
              const t = d.tipos.find((x) => x.nome === e.target.value);
              if (t) setResponsavel(t.responsavel);
            }}
          >
            {d.tipos.map((t) => (
              <option key={t.id} value={t.nome}>
                {t.nome} ({t.onde})
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="resp">
          De quem é a responsabilidade
        </label>
        <select id="resp" className="campo" value={responsavel} onChange={(e) => setResponsavel(e.target.value as EmpresaResp)}>
          {RESPONSAVEIS.map((x) => (
            <option key={x} value={x}>
              {x}
            </option>
          ))}
        </select>
        <p className="text-xs" style={{ color: "hsl(var(--muted-fg))" }}>
          É por este campo que o indicador separa as horas perdidas por empresa.
        </p>
      </div>

      {exigeChamado ? (
        <div className="grid gap-1">
          <label className="text-xs font-medium" htmlFor="chamado">
            Número do chamado
          </label>
          <input id="chamado" className="campo" value={chamado} onChange={(e) => setChamado(e.target.value)} placeholder="ex.: INC-10482" />
        </div>
      ) : null}

      <div className="grid gap-1">
        <label className="text-xs font-medium" htmlFor="desc">
          Descrição
        </label>
        <textarea id="desc" className="campo" rows={3} value={descricao} onChange={(e) => setDescricao(e.target.value)} />
      </div>

      <div className="flex justify-end gap-2">
        <button className="btn btn-sec" onClick={onFechar}>
          Cancelar
        </button>
        <button
          className="btn btn-pri"
          disabled={!valido || salvando}
          onClick={async () => {
            setSalvando(true);
            const ok = await d.abrirOcorrencia({
              romaneioId: r.id,
              cp: emissao ? 2 : r.etapa_atual,
              tipo,
              responsavel,
              motivo: emissao ? motivo : undefined,
              descricao: descricao.trim() || undefined,
              chamado: chamado.trim() || undefined,
            });
            if (ok) onFechar();
            else setSalvando(false);
          }}
        >
          Abrir ocorrência
        </button>
      </div>
    </Modal>
  );
}
