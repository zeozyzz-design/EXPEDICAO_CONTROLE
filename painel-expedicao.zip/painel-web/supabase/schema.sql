-- =====================================================================
-- Painel de Controle de Expedição — Iveco Group
-- Schema completo: rode este arquivo inteiro no SQL Editor do Supabase.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- Tipos
-- ---------------------------------------------------------------------
do $$ begin
  create type perfil_tipo as enum ('celere', 'ceva', 'transportadora', 'gerencia');
exception when duplicate_object then null; end $$;

do $$ begin
  create type empresa_resp as enum ('CEVA', 'Celere', 'Transportadora', 'Inovatech');
exception when duplicate_object then null; end $$;

do $$ begin
  create type evento_tipo as enum ('checkpoint', 'estorno');
exception when duplicate_object then null; end $$;

-- ---------------------------------------------------------------------
-- Perfis — um por usuário do Supabase Auth
-- ---------------------------------------------------------------------
create table if not exists perfis (
  id uuid primary key references auth.users(id) on delete cascade,
  nome text not null,
  tipo perfil_tipo not null,
  transportadora text,
  ativo boolean not null default true,
  criado_em timestamptz not null default now(),
  constraint transportadora_obrigatoria
    check (tipo <> 'transportadora' or transportadora is not null)
);

-- ---------------------------------------------------------------------
-- Etapas do fluxo (CP1..CP6) — cadastro, não código
-- ---------------------------------------------------------------------
create table if not exists etapas (
  cp smallint primary key,
  nome text not null,
  curto text not null,
  setor text not null check (setor in ('CEVA', 'Celere', 'Transportadora'))
);

insert into etapas (cp, nome, curto, setor) values
  (1, 'Romaneio fechado e enviado', 'Romaneio enviado', 'CEVA'),
  (2, 'Emissão do NOTFIS', 'NOTFIS emitido', 'Celere'),
  (3, 'Recebimento do NOTFIS', 'NOTFIS recebido', 'Transportadora'),
  (4, 'Conferência e emissão do CTe', 'CTe emitido', 'Transportadora'),
  (5, 'Início de carregamento', 'Carregamento iniciado', 'Transportadora'),
  (6, 'Fim de descarregamento', 'Descarregamento concluído', 'Transportadora')
on conflict (cp) do update set nome = excluded.nome, curto = excluded.curto, setor = excluded.setor;

-- ---------------------------------------------------------------------
-- Romaneios
-- ---------------------------------------------------------------------
create table if not exists romaneios (
  id uuid primary key default gen_random_uuid(),
  numero text not null,
  transportadora text not null,
  qtd_notas integer not null check (qtd_notas > 0),
  anexo_path text,
  anexo_nome text,
  etapa_atual smallint not null default 1,
  criado_em timestamptz not null default now(),
  criado_por uuid not null references perfis(id),
  unique (numero, transportadora)
);

create index if not exists romaneios_etapa_idx on romaneios (etapa_atual, transportadora);
create index if not exists romaneios_criado_idx on romaneios (criado_em desc);

-- ---------------------------------------------------------------------
-- Eventos — append-only, carimbo do servidor, cadeia de hash
-- ---------------------------------------------------------------------
create table if not exists eventos (
  id uuid primary key default gen_random_uuid(),
  romaneio_id uuid not null references romaneios(id) on delete restrict,
  cp smallint not null references etapas(cp),
  tipo evento_tipo not null default 'checkpoint',
  ocorrido_em timestamptz not null default now(),
  autor_id uuid not null references perfis(id),
  autor_nome text not null,
  por_master boolean not null default false,
  nota text,
  seq bigint generated always as identity,
  hash_prev text not null default '',
  hash text not null default ''
);

create index if not exists eventos_romaneio_idx on eventos (romaneio_id, seq);

-- ---------------------------------------------------------------------
-- Ocorrências
-- ---------------------------------------------------------------------
create table if not exists tipos_ocorrencia (
  id serial primary key,
  nome text not null unique,
  onde text not null,
  responsavel empresa_resp not null,
  exige_chamado boolean not null default false,
  ativo boolean not null default true
);

insert into tipos_ocorrencia (nome, onde, responsavel, exige_chamado) values
  ('Emissão parada', 'CP2', 'Inovatech', true),
  ('NF não migrou para emissão', 'CP1 → CP2', 'Inovatech', true),
  ('NOTFIS não gerou', 'CP2', 'Inovatech', true),
  ('NOTFIS gerado com erro ou incompleto', 'CP2', 'Celere', true),
  ('Transportadora não recebeu o arquivo', 'CP2 → CP3', 'Celere', false),
  ('Divergência na conferência do CTe', 'CP4', 'Celere', false),
  ('Romaneio enviado com divergência', 'CP1', 'CEVA', false),
  ('Veículo não apresentado', 'CP4 → CP5', 'Transportadora', false),
  ('Sistema indisponível', 'Qualquer', 'Inovatech', true),
  ('Outro', 'Qualquer', 'Celere', false)
on conflict (nome) do nothing;

create table if not exists ocorrencias (
  id uuid primary key default gen_random_uuid(),
  romaneio_id uuid not null references romaneios(id) on delete restrict,
  cp smallint not null,
  tipo text not null,
  motivo text,
  descricao text,
  responsavel empresa_resp not null,
  chamado text,
  aberta_em timestamptz not null default now(),
  fechada_em timestamptz,
  aberta_por uuid not null references perfis(id),
  fechada_por uuid references perfis(id)
);

create index if not exists ocorrencias_romaneio_idx on ocorrencias (romaneio_id);
create index if not exists ocorrencias_abertas_idx on ocorrencias (fechada_em, aberta_em);

-- ---------------------------------------------------------------------
-- Metas de SLA com vigência
-- ---------------------------------------------------------------------
create table if not exists sla_metas (
  id serial primary key,
  cp smallint not null references etapas(cp),
  transportadora text,
  minutos integer not null check (minutos > 0),
  vigente_de timestamptz not null default now(),
  vigente_ate timestamptz
);

insert into sla_metas (cp, minutos) values (2, 20), (3, 60), (4, 120), (5, 60), (6, 240)
on conflict do nothing;

-- =====================================================================
-- IMUTABILIDADE
-- Eventos nunca podem ser alterados nem apagados. Uma correção é um
-- evento de estorno; o registro original permanece.
-- =====================================================================
create or replace function bloquear_alteracao_evento()
returns trigger language plpgsql as $$
begin
  raise exception 'Eventos são imutáveis: registre um estorno em vez de alterar o checkpoint %', old.id;
end $$;

drop trigger if exists eventos_sem_update on eventos;
create trigger eventos_sem_update before update on eventos
  for each row execute function bloquear_alteracao_evento();

drop trigger if exists eventos_sem_delete on eventos;
create trigger eventos_sem_delete before delete on eventos
  for each row execute function bloquear_alteracao_evento();

-- Cadeia de hash, calculada no servidor a partir do evento anterior
create or replace function encadear_evento()
returns trigger language plpgsql as $$
declare anterior text;
begin
  select e.hash into anterior
    from eventos e
   where e.romaneio_id = new.romaneio_id
   order by e.seq desc
   limit 1;

  new.hash_prev := coalesce(anterior, '');
  new.hash := encode(
    digest(
      concat_ws('|', new.romaneio_id::text, new.cp::text, new.tipo::text,
                to_char(new.ocorrido_em at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MSZ'),
                new.autor_nome, coalesce(new.nota, ''), new.hash_prev),
      'sha256'),
    'hex');
  return new;
end $$;

drop trigger if exists eventos_encadear on eventos;
create trigger eventos_encadear before insert on eventos
  for each row execute function encadear_evento();

-- Verificação da cadeia: recalcula tudo e aponta o que não confere
create or replace function verificar_integridade()
returns table (romaneio_id uuid, numero text, cp smallint, ocorrido_em timestamptz, problema text)
language sql stable security definer set search_path = public as $$
  with recalculado as (
    select e.*, r.numero,
           lag(e.hash) over (partition by e.romaneio_id order by e.seq) as hash_anterior_real,
           encode(digest(concat_ws('|', e.romaneio_id::text, e.cp::text, e.tipo::text,
                    to_char(e.ocorrido_em at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MSZ'),
                    e.autor_nome, coalesce(e.nota, ''), e.hash_prev), 'sha256'), 'hex') as hash_calculado
      from eventos e join romaneios r on r.id = e.romaneio_id
  )
  select romaneio_id, numero, cp, ocorrido_em,
         case when hash <> hash_calculado then 'conteúdo alterado após a gravação'
              else 'elo rompido com o evento anterior' end
    from recalculado
   where hash <> hash_calculado
      or hash_prev is distinct from coalesce(hash_anterior_real, '')
   order by ocorrido_em;
$$;

-- =====================================================================
-- FUNÇÕES DE ESCRITA
-- Toda gravação passa por aqui: a hora é sempre now() do banco, nunca
-- um valor vindo do navegador.
-- =====================================================================
create or replace function meu_perfil()
returns perfis language sql stable security definer set search_path = public as $$
  select * from perfis where id = auth.uid() and ativo;
$$;

create or replace function registrar_checkpoint(
  p_romaneio uuid, p_cp smallint, p_tipo evento_tipo default 'checkpoint', p_nota text default null)
returns eventos language plpgsql security definer set search_path = public as $$
declare
  eu perfis;
  rom romaneios;
  et etapas;
  novo eventos;
  proprio boolean;
  nova_etapa smallint;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  if eu is null then raise exception 'Sem perfil ativo.'; end if;
  if eu.tipo = 'gerencia' then raise exception 'A gerência tem acesso somente leitura.'; end if;

  select * into rom from romaneios where id = p_romaneio;
  if rom is null then raise exception 'Romaneio não encontrado.'; end if;

  select * into et from etapas where cp = p_cp;
  if et is null then raise exception 'Etapa % não existe.', p_cp; end if;

  proprio := (et.setor = 'CEVA' and eu.tipo = 'ceva')
          or (et.setor = 'Celere' and eu.tipo = 'celere')
          or (et.setor = 'Transportadora' and eu.tipo = 'transportadora' and eu.transportadora = rom.transportadora);

  -- A Celere é o acesso master: registra em nome de terceiro, e isso fica marcado.
  if not proprio and eu.tipo <> 'celere' then
    raise exception 'Esta etapa é responsabilidade de %.', et.setor;
  end if;

  if eu.tipo = 'transportadora' and eu.transportadora is distinct from rom.transportadora then
    raise exception 'Este romaneio não é da sua transportadora.';
  end if;

  insert into eventos (romaneio_id, cp, tipo, autor_id, autor_nome, por_master, nota)
  values (p_romaneio, p_cp, p_tipo, eu.id, eu.nome, not proprio, p_nota)
  returning * into novo;

  nova_etapa := case when p_tipo = 'estorno' then greatest(1, p_cp - 1) else p_cp end;
  update romaneios set etapa_atual = nova_etapa where id = p_romaneio;

  return novo;
end $$;

create or replace function lancar_romaneio(
  p_numero text, p_transportadora text, p_qtd_notas integer,
  p_anexo_path text default null, p_anexo_nome text default null)
returns romaneios language plpgsql security definer set search_path = public as $$
declare eu perfis; nova romaneios;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  if eu is null then raise exception 'Sem perfil ativo.'; end if;
  if eu.tipo not in ('ceva', 'celere') then raise exception 'Só a CEVA e a Celere lançam romaneios.'; end if;

  insert into romaneios (numero, transportadora, qtd_notas, anexo_path, anexo_nome, criado_por)
  values (trim(p_numero), p_transportadora, p_qtd_notas, p_anexo_path, p_anexo_nome, eu.id)
  returning * into nova;

  insert into eventos (romaneio_id, cp, tipo, autor_id, autor_nome, por_master)
  values (nova.id, 1, 'checkpoint', eu.id, eu.nome, eu.tipo <> 'ceva');

  return nova;
end $$;

create or replace function abrir_ocorrencia(
  p_romaneio uuid, p_cp smallint, p_tipo text, p_responsavel empresa_resp,
  p_motivo text default null, p_descricao text default null, p_chamado text default null)
returns ocorrencias language plpgsql security definer set search_path = public as $$
declare eu perfis; nova ocorrencias;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  if eu is null then raise exception 'Sem perfil ativo.'; end if;
  if eu.tipo = 'gerencia' then raise exception 'A gerência tem acesso somente leitura.'; end if;

  insert into ocorrencias (romaneio_id, cp, tipo, motivo, descricao, responsavel, chamado, aberta_por)
  values (p_romaneio, p_cp, p_tipo, p_motivo, p_descricao, p_responsavel, p_chamado, eu.id)
  returning * into nova;
  return nova;
end $$;

create or replace function fechar_ocorrencia(p_ocorrencia uuid)
returns ocorrencias language plpgsql security definer set search_path = public as $$
declare eu perfis; alvo ocorrencias;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  if eu is null then raise exception 'Sem perfil ativo.'; end if;
  if eu.tipo = 'gerencia' then raise exception 'A gerência tem acesso somente leitura.'; end if;

  update ocorrencias set fechada_em = now(), fechada_por = eu.id
   where id = p_ocorrencia and fechada_em is null
  returning * into alvo;

  if alvo is null then raise exception 'Ocorrência já fechada ou inexistente.'; end if;
  return alvo;
end $$;

-- Criação de login: só a Celere. Cria o usuário no Auth e o perfil junto.
create or replace function criar_perfil(
  p_user_id uuid, p_nome text, p_tipo perfil_tipo, p_transportadora text default null)
returns perfis language plpgsql security definer set search_path = public as $$
declare eu perfis; novo perfis;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  -- O primeiro perfil do sistema é sempre a Celere, criado sem exigir master.
  if (select count(*) from perfis) > 0 then
    if eu is null or eu.tipo <> 'celere' then raise exception 'Só a Celere cria logins.'; end if;
  elsif p_tipo <> 'celere' then
    raise exception 'O primeiro acesso do sistema precisa ser da Celere.';
  end if;

  insert into perfis (id, nome, tipo, transportadora)
  values (p_user_id, p_nome, p_tipo, p_transportadora)
  returning * into novo;
  return novo;
end $$;

create or replace function definir_meta_sla(p_cp smallint, p_minutos integer)
returns void language plpgsql security definer set search_path = public as $$
declare eu perfis;
begin
  select * into eu from perfis where id = auth.uid() and ativo;
  if eu is null or eu.tipo <> 'celere' then raise exception 'Só a Celere altera metas de SLA.'; end if;

  update sla_metas set vigente_ate = now()
   where cp = p_cp and transportadora is null and vigente_ate is null;
  insert into sla_metas (cp, minutos) values (p_cp, p_minutos);
end $$;

-- =====================================================================
-- ROW LEVEL SECURITY
-- A transportadora só enxerga as cargas dela — no banco, não na tela.
-- =====================================================================
alter table perfis enable row level security;
alter table romaneios enable row level security;
alter table eventos enable row level security;
alter table ocorrencias enable row level security;
alter table etapas enable row level security;
alter table tipos_ocorrencia enable row level security;
alter table sla_metas enable row level security;

create or replace function minha_transportadora()
returns text language sql stable security definer set search_path = public as $$
  select case when tipo = 'transportadora' then transportadora else null end
    from perfis where id = auth.uid() and ativo;
$$;

create or replace function sou_celere()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from perfis where id = auth.uid() and ativo and tipo = 'celere');
$$;

-- Perfis: cada um lê o próprio; a Celere lê todos.
drop policy if exists perfis_leitura on perfis;
create policy perfis_leitura on perfis for select to authenticated
  using (id = auth.uid() or sou_celere());

drop policy if exists perfis_update on perfis;
create policy perfis_update on perfis for update to authenticated
  using (sou_celere()) with check (sou_celere());

-- Romaneios: transportadora vê só os seus.
drop policy if exists romaneios_leitura on romaneios;
create policy romaneios_leitura on romaneios for select to authenticated
  using (minha_transportadora() is null or transportadora = minha_transportadora());

-- Eventos e ocorrências seguem a visibilidade do romaneio.
drop policy if exists eventos_leitura on eventos;
create policy eventos_leitura on eventos for select to authenticated
  using (exists (select 1 from romaneios r where r.id = eventos.romaneio_id
                   and (minha_transportadora() is null or r.transportadora = minha_transportadora())));

drop policy if exists ocorrencias_leitura on ocorrencias;
create policy ocorrencias_leitura on ocorrencias for select to authenticated
  using (exists (select 1 from romaneios r where r.id = ocorrencias.romaneio_id
                   and (minha_transportadora() is null or r.transportadora = minha_transportadora())));

-- Cadastros: leitura para todos os autenticados.
drop policy if exists etapas_leitura on etapas;
create policy etapas_leitura on etapas for select to authenticated using (true);

drop policy if exists tipos_leitura on tipos_ocorrencia;
create policy tipos_leitura on tipos_ocorrencia for select to authenticated using (true);

drop policy if exists sla_leitura on sla_metas;
create policy sla_leitura on sla_metas for select to authenticated using (true);

-- Nenhuma política de INSERT/UPDATE/DELETE direta: toda escrita passa
-- pelas funções acima, que carimbam a hora do servidor.
revoke insert, update, delete on eventos from authenticated, anon;
revoke insert, update, delete on romaneios from authenticated, anon;
revoke insert, update, delete on ocorrencias from authenticated, anon;

-- =====================================================================
-- REALTIME — a fila aparece sozinha
-- =====================================================================
do $$ begin
  alter publication supabase_realtime add table romaneios;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table eventos;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table ocorrencias;
exception when duplicate_object then null; end $$;

-- =====================================================================
-- STORAGE — anexos da CEVA
-- =====================================================================
insert into storage.buckets (id, name, public)
values ('anexos', 'anexos', false)
on conflict (id) do nothing;

drop policy if exists anexos_leitura on storage.objects;
create policy anexos_leitura on storage.objects for select to authenticated
  using (bucket_id = 'anexos');

drop policy if exists anexos_envio on storage.objects;
create policy anexos_envio on storage.objects for insert to authenticated
  with check (bucket_id = 'anexos');

-- =====================================================================
-- VIEW DE TEMPOS — base dos indicadores
-- =====================================================================
create or replace view tempos_etapa as
with carimbos as (
  select romaneio_id, cp, max(ocorrido_em) as em
    from eventos where tipo = 'checkpoint'
   group by romaneio_id, cp
)
select a.romaneio_id, a.cp,
       b.em as inicio, a.em as fim,
       extract(epoch from (a.em - b.em)) / 60 as minutos
  from carimbos a
  join carimbos b on b.romaneio_id = a.romaneio_id and b.cp = a.cp - 1;
